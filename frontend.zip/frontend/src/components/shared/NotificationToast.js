import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { FiX, FiBell, FiCheck, FiAlertCircle, FiInfo } from 'react-icons/fi';

const iconMap = {
  order_update: <FiCheck />,
  new_order: <FiBell />,
  new_assignment: <FiAlertCircle />,
  default: <FiInfo />,
};

const typeMap = {
  order_update: 'info',
  new_order: 'success',
  new_assignment: 'warning',
};

const NotificationToast = () => {
  const { notifications, clearNotification, clearAllNotifications } = useAuth();
  const [visible, setVisible] = useState([]);

  useEffect(() => {
    if (notifications.length > visible.length) {
      const newNotifs = notifications.slice(0, 3);
      setVisible(newNotifs);
      
      const timer = setTimeout(() => {
        setVisible((prev) => prev.slice(1));
        clearNotification(0);
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [notifications]);

  if (visible.length === 0) return null;

  return (
    <div className="toast-container">
      {visible.map((notification, index) => (
        <div
          key={index}
          className={`toast ${typeMap[notification.type] || 'info'}`}
        >
          <span className="toast-icon">
            {iconMap[notification.type] || iconMap.default}
          </span>
          <div className="toast-message">
            <strong>{notification.title}</strong>
            <br />
            {notification.message}
          </div>
          <span
            className="toast-close"
            onClick={() => {
              setVisible((prev) => prev.filter((_, i) => i !== index));
              clearNotification(index);
            }}
          >
            <FiX />
          </span>
        </div>
      ))}
    </div>
  );
};

export default NotificationToast;