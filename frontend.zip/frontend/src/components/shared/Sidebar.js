import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  FiHome, FiShoppingBag, FiClock, FiHeart, FiSettings, FiLogOut,
  FiPackage, FiTruck, FiMapPin, FiUsers, FiBarChart2, FiBell,
  FiGrid, FiEdit, FiStar, FiDollarSign
} from 'react-icons/fi';

const navItems = {
  customer: [
    { path: '/customer', icon: <FiHome />, label: 'Home' },
    { path: '/customer/orders', icon: <FiClock />, label: 'My Orders' }
  ],
  restaurant: [
    { path: '/restaurant', icon: <FiHome />, label: 'Dashboard' },
    { path: '/restaurant/menu', icon: <FiGrid />, label: 'Menu Management' },
    { path: '/restaurant/orders', icon: <FiShoppingBag />, label: 'Orders' }
  ],
  rider: [
    { path: '/rider', icon: <FiHome />, label: 'Dashboard' },
    { path: '/rider/history', icon: <FiClock />, label: 'Delivery History' }
  ],
  admin: [
    { path: '/admin', icon: <FiHome />, label: 'Dashboard' },
    { path: '/admin/users', icon: <FiUsers />, label: 'User Management' },
    { path: '/admin/orders', icon: <FiShoppingBag />, label: 'All Orders' }
  ],
};

const Sidebar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const role = user?.role || 'customer';
  const items = navItems[role] || [];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const initials = user?.firstName
    ? user.firstName.charAt(0).toUpperCase()
    : '?';

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="brand-icon">🍕</div>
        <h2>Food<span>Fleet</span></h2>
      </div>

      <div className="sidebar-user">
        <div className="user-avatar">{initials}</div>
        <div className="user-info">
          <div className="user-name">{user?.firstName} {user?.lastName}</div>
          <div className="user-role">{role}</div>
        </div>
      </div>

      <nav className="sidebar-nav">
        <div className="nav-section">
          <div className="nav-section-title">Navigation</div>
          {items.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === `/${role}`}
              className={({ isActive }) =>
                `nav-item ${isActive ? 'active' : ''}`
              }
            >
              <span className="nav-icon">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </div>
      </nav>

      <div className="sidebar-footer">
        <div className="nav-item" onClick={handleLogout}>
          <span className="nav-icon"><FiLogOut /></span>
          <span>Logout</span>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;