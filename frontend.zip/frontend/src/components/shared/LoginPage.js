
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  FiMail,
  FiLock,
  FiEye,
  FiEyeOff,
  FiTruck,
  FiClock,
  FiShield,
} from 'react-icons/fi';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const user = await login(email, password);
      navigate(`/${user.role}`);
    } catch (err) {
      setError(err.response?.data?.error || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      {/* LEFT SIDE */}
      <div style={styles.leftPanel}>
        <div style={styles.overlay} />

        <div style={styles.brandSection}>
          <div style={styles.logoBox}>
            <FiTruck size={28} />
          </div>

          <h1 style={styles.brandTitle}>
            Food<span style={{ color: '#FF6B35' }}>Fleet</span>
          </h1>

          <p style={styles.brandSubtitle}>
            Premium food delivery management platform for customers,
            restaurants, and riders.
          </p>
        </div>

        <div style={styles.infoCard}>
          <div style={styles.infoRow}>
            <div style={styles.iconCircle}>
              <FiClock size={18} />
            </div>

            <div>
              <h4 style={styles.infoTitle}>Fast Delivery</h4>
              <p style={styles.infoText}>
                Optimized dispatching for quick and reliable deliveries.
              </p>
            </div>
          </div>

          <div style={styles.infoRow}>
            <div style={styles.iconCircle}>
              <FiShield size={18} />
            </div>

            <div>
              <h4 style={styles.infoTitle}>Secure Platform</h4>
              <p style={styles.infoText}>
                Enterprise-grade authentication and secure order processing.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT SIDE */}
      <div style={styles.rightPanel}>
        <div style={styles.formCard}>
          <div style={styles.formHeader}>
            <h2 style={styles.formTitle}>Welcome Back</h2>
            <p style={styles.formSubtitle}>
              Sign in to continue to your dashboard.
            </p>
          </div>

          {error && <div style={styles.errorBanner}>{error}</div>}

          <form onSubmit={handleSubmit}>
            <div style={styles.formGroup}>
              <label style={styles.label}>Email Address</label>

              <div style={styles.inputWrapper}>
                <FiMail style={styles.inputIcon} />

                <input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  style={styles.input}
                />
              </div>
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Password</label>

              <div style={styles.inputWrapper}>
                <FiLock style={styles.inputIcon} />

                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  style={{ ...styles.input, paddingRight: 48 }}
                />

                <button
                  type="button"
                  style={styles.eyeBtn}
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <FiEyeOff /> : <FiEye />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              style={styles.loginBtn}
              disabled={loading}
            >
              {loading ? 'Signing In...' : 'Sign In'}
            </button>
          </form>

          <div style={styles.roleSection}>
            <div style={styles.roleGrid}>
              <button
                style={styles.roleCard}
                onClick={() => {
                  setEmail('customer@demo.com');
                  setPassword('demo123');
                }}
              >
                <span style={styles.roleTitle}>Customer</span>
                <span style={styles.roleText}>Browse and order food</span>
              </button>

              <button
                style={styles.roleCard}
                onClick={() => {
                  setEmail('restaurant@demo.com');
                  setPassword('demo123');
                }}
              >
                <span style={styles.roleTitle}>Restaurant</span>
                <span style={styles.roleText}>Manage menus and orders</span>
              </button>

              <button
                style={styles.roleCard}
                onClick={() => {
                  setEmail('rider@demo.com');
                  setPassword('demo123');
                }}
              >
                <span style={styles.roleTitle}>Rider</span>
                <span style={styles.roleText}>Track and deliver orders</span>
              </button>

              <button
                style={styles.roleCard}
                onClick={() => {
                  setEmail('admin@demo.com');
                  setPassword('demo123');
                }}
              >
                <span style={styles.roleTitle}>Admin</span>
                <span style={styles.roleText}>Platform administration</span>
              </button>
            </div>
          </div>

          <p style={styles.signupText}>
            Don&apos;t have an account?{' '}
            <Link to="/register" style={styles.signupLink}>
              Create Account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    minHeight: '100vh',
    display: 'grid',
    gridTemplateColumns: '1.1fr 0.9fr',
    background: '#F1F5F9',
    fontFamily: 'Inter, sans-serif',
  },

  leftPanel: {
    position: 'relative',
    background:
      'radial-gradient(circle at top right, rgba(255,107,53,0.18), transparent 30%), linear-gradient(135deg, #020617 0%, #0F172A 55%, #111827 100%)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '60px',
    overflow: 'hidden',
  },

  overlay: {
    display: 'none',
  },

  brandSection: {
    width: '100%',
    maxWidth: '520px',
  },

  logoBox: {
    width: '72px',
    height: '72px',
    borderRadius: '22px',
    background: 'linear-gradient(135deg, #FF6B35 0%, #FB923C 100%)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#FFFFFF',
    marginBottom: '32px',
    boxShadow: '0 20px 40px rgba(255,107,53,0.35)',
  },

  brandTitle: {
    fontSize: '4rem',
    lineHeight: 1,
    fontWeight: 800,
    color: '#FFFFFF',
    marginBottom: '20px',
    letterSpacing: '-2px',
  },

  brandSubtitle: {
    fontSize: '1.08rem',
    lineHeight: 1.9,
    color: '#CBD5E1',
    maxWidth: '460px',
    marginBottom: '48px',
  },

  infoCard: {
    width: '100%',
    maxWidth: '500px',
    background: 'rgba(255,255,255,0.05)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: '28px',
    padding: '34px',
    backdropFilter: 'blur(14px)',
  },

  infoRow: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '18px',
  },

  iconCircle: {
    minWidth: '48px',
    height: '48px',
    borderRadius: '16px',
    background: 'rgba(255,255,255,0.08)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#FF6B35',
  },

  infoTitle: {
    color: '#FFFFFF',
    fontWeight: 700,
    marginBottom: '6px',
    fontSize: '1rem',
  },

  infoText: {
    color: '#CBD5E1',
    lineHeight: 1.7,
    fontSize: '0.95rem',
  },

  rightPanel: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '40px',
  },

  formCard: {
    width: '100%',
    maxWidth: '460px',
    background: '#FFFFFF',
    borderRadius: '30px',
    padding: '44px',
    boxShadow: '0 20px 50px rgba(15,23,42,0.08)',
    border: '1px solid #E2E8F0',
  },

  formHeader: {
    marginBottom: '30px',
  },

  formTitle: {
    fontSize: '2.2rem',
    fontWeight: 800,
    color: '#0F172A',
    marginBottom: '8px',
    letterSpacing: '-1px',
  },

  formSubtitle: {
    color: '#64748B',
    fontSize: '0.98rem',
  },

  formGroup: {
    marginBottom: '22px',
  },

  label: {
    display: 'block',
    marginBottom: '10px',
    fontWeight: 600,
    color: '#334155',
    fontSize: '0.92rem',
  },

  inputWrapper: {
    position: 'relative',
  },

  inputIcon: {
    position: 'absolute',
    top: '50%',
    left: '16px',
    transform: 'translateY(-50%)',
    color: '#94A3B8',
  },

  input: {
    width: '100%',
    height: '58px',
    borderRadius: '18px',
    border: '1px solid #CBD5E1',
    background: '#F8FAFC',
    paddingLeft: '48px',
    fontSize: '0.95rem',
    transition: 'all 0.2s ease',
    outline: 'none',
    boxSizing: 'border-box',
  },

  eyeBtn: {
    position: 'absolute',
    top: '50%',
    right: '16px',
    transform: 'translateY(-50%)',
    background: 'transparent',
    border: 'none',
    color: '#94A3B8',
    cursor: 'pointer',
  },

  loginBtn: {
    width: '100%',
    height: '58px',
    border: 'none',
    borderRadius: '18px',
    background: 'linear-gradient(135deg, #FF6B35 0%, #F97316 100%)',
    color: '#FFFFFF',
    fontWeight: 700,
    fontSize: '1rem',
    cursor: 'pointer',
    marginTop: '10px',
    boxShadow: '0 16px 35px rgba(249,115,22,0.28)',
  },

  errorBanner: {
    background: '#FEF2F2',
    border: '1px solid #FECACA',
    color: '#DC2626',
    borderRadius: '16px',
    padding: '14px 16px',
    marginBottom: '20px',
    fontSize: '0.9rem',
  },

  roleSection: {
    marginTop: '30px',
    paddingTop: '26px',
    borderTop: '1px solid #E2E8F0',
  },

  roleGrid: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '14px',
  },

  roleCard: {
    border: '1px solid #E2E8F0',
    borderRadius: '18px',
    background: '#FFFFFF',
    padding: '18px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    textAlign: 'left',
  },

  roleTitle: {
    display: 'block',
    fontWeight: 700,
    color: '#0F172A',
    marginBottom: '6px',
  },

  roleText: {
    color: '#64748B',
    fontSize: '0.82rem',
    lineHeight: 1.5,
  },

  signupText: {
    textAlign: 'center',
    marginTop: '28px',
    color: '#64748B',
    fontSize: '0.94rem',
  },

  signupLink: {
    color: '#FF6B35',
    fontWeight: 700,
    textDecoration: 'none',
  },
};

export default LoginPage;
