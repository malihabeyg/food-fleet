import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  FiMail,
  FiLock,
  FiUser,
  FiPhone,
  FiEye,
  FiEyeOff,
  FiArrowLeft,
} from 'react-icons/fi';

const RegisterPage = () => {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState('customer');

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',

    restaurantName: '',
    cuisineType: '',
    address: '',
    city: '',

    vehicleType: 'bicycle',
    licenseNumber: '',
  });

  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);

    try {
      const data = {
        email: formData.email,
        password: formData.password,
        role,
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
      };

      if (role === 'restaurant') {
        data.restaurantName = formData.restaurantName;
        data.cuisineType = formData.cuisineType;
        data.address = formData.address;
        data.city = formData.city;
      }

      if (role === 'rider') {
        data.vehicleType = formData.vehicleType;
        data.licenseNumber = formData.licenseNumber;
      }

      const user = await register(data);

      navigate(`/${user.role}`);
    } catch (err) {
      setError(
        err.response?.data?.error ||
          'Registration failed. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const roles = [
    {
      id: 'customer',
      label: 'Customer',
      desc: 'Browse restaurants and place food orders',
    },
    {
      id: 'restaurant',
      label: 'Restaurant',
      desc: 'Manage menus and restaurant operations',
    },
    {
      id: 'rider',
      label: 'Rider',
      desc: 'Accept deliveries and manage routes',
    },
    {
      id: 'admin',
      label: 'Admin',
      desc: 'Monitor platform analytics and operations',
    },
  ];

  return (
    <div style={styles.container}>
      {/* LEFT SIDE */}
      <div style={styles.leftPanel}>
        <div style={styles.brandContent}>
          <div style={styles.logoBox}>FF</div>

          <h1 style={styles.brandTitle}>
            Food<span style={{ color: '#FF6B35' }}>Fleet</span>
          </h1>

          <p style={styles.brandSubtitle}>
            Modern food delivery infrastructure for customers,
            restaurants, riders, and administrators.
          </p>

          <div style={styles.featureCard}>
            <div style={styles.featureItem}>
              <div style={styles.featureDot} />

              <div>
                <h4 style={styles.featureTitle}>
                  Real-time Operations
                </h4>

                <p style={styles.featureText}>
                  Smart order tracking and delivery coordination.
                </p>
              </div>
            </div>

            <div style={styles.featureItem}>
              <div style={styles.featureDot} />

              <div>
                <h4 style={styles.featureTitle}>
                  Secure Platform
                </h4>

                <p style={styles.featureText}>
                  Reliable authentication and enterprise-grade
                  workflows.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT SIDE */}
      <div style={styles.rightPanel}>
        <div style={styles.formContainer}>
          {step === 1 ? (
            <>
              <h2 style={styles.formTitle}>Create Account</h2>

              <p style={styles.formSubtitle}>
                Choose your account type
              </p>

              <div style={styles.roleGrid}>
                {roles.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    style={{
                      ...styles.roleCard,
                      border:
                        role === r.id
                          ? '2px solid #FF6B35'
                          : '1px solid #E2E8F0',
                      background:
                        role === r.id ? '#FFF7ED' : '#FFFFFF',
                    }}
                    onClick={() => setRole(r.id)}
                  >
                    <div style={styles.roleBadge}>
                      {r.label.charAt(0)}
                    </div>

                    <h4
                      style={{
                        ...styles.roleLabel,
                        color:
                          role === r.id
                            ? '#EA580C'
                            : '#0F172A',
                      }}
                    >
                      {r.label}
                    </h4>

                    <p style={styles.roleDesc}>{r.desc}</p>
                  </button>
                ))}
              </div>

              <button
                style={styles.continueBtn}
                onClick={() => setStep(2)}
              >
                Continue
              </button>
            </>
          ) : (
            <>
              <button
                style={styles.backBtn}
                onClick={() => setStep(1)}
              >
                <FiArrowLeft />
                Back
              </button>

              <h2 style={styles.formTitle}>
                {role.charAt(0).toUpperCase() + role.slice(1)} Details
              </h2>

              {error && (
                <div style={styles.errorBanner}>{error}</div>
              )}

              <form onSubmit={handleSubmit}>
                <div style={styles.row}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>
                      First Name
                    </label>

                    <div style={styles.inputWrapper}>
                      <FiUser style={styles.inputIcon} />

                      <input
                        type="text"
                        name="firstName"
                        placeholder="John"
                        value={formData.firstName}
                        onChange={handleChange}
                        required
                        style={styles.input}
                      />
                    </div>
                  </div>

                  <div style={styles.formGroup}>
                    <label style={styles.label}>
                      Last Name
                    </label>

                    <div style={styles.inputWrapper}>
                      <FiUser style={styles.inputIcon} />

                      <input
                        type="text"
                        name="lastName"
                        placeholder="Doe"
                        value={formData.lastName}
                        onChange={handleChange}
                        style={styles.input}
                      />
                    </div>
                  </div>
                </div>

                <div style={styles.formGroup}>
                  <label style={styles.label}>
                    Email Address
                  </label>

                  <div style={styles.inputWrapper}>
                    <FiMail style={styles.inputIcon} />

                    <input
                      type="email"
                      name="email"
                      placeholder="you@example.com"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      style={styles.input}
                    />
                  </div>
                </div>

                <div style={styles.formGroup}>
                  <label style={styles.label}>
                    Phone Number
                  </label>

                  <div style={styles.inputWrapper}>
                    <FiPhone style={styles.inputIcon} />

                    <input
                      type="tel"
                      name="phone"
                      placeholder="+1 (555) 000-0000"
                      value={formData.phone}
                      onChange={handleChange}
                      style={styles.input}
                    />
                  </div>
                </div>

                <div style={styles.row}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Password</label>

                    <div style={styles.inputWrapper}>
                      <FiLock style={styles.inputIcon} />

                      <input
                        type={
                          showPassword ? 'text' : 'password'
                        }
                        name="password"
                        placeholder="Min 6 characters"
                        value={formData.password}
                        onChange={handleChange}
                        required
                        style={styles.input}
                      />
                    </div>
                  </div>

                  <div style={styles.formGroup}>
                    <label style={styles.label}>
                      Confirm Password
                    </label>

                    <div style={styles.inputWrapper}>
                      <FiLock style={styles.inputIcon} />

                      <input
                        type={
                          showPassword ? 'text' : 'password'
                        }
                        name="confirmPassword"
                        placeholder="Re-enter password"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        required
                        style={styles.input}
                      />

                      <button
                        type="button"
                        style={styles.eyeBtn}
                        onClick={() =>
                          setShowPassword(!showPassword)
                        }
                      >
                        {showPassword ? (
                          <FiEyeOff />
                        ) : (
                          <FiEye />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {role === 'restaurant' && (
                  <>
                    <div style={styles.formGroup}>
                      <label style={styles.label}>
                        Restaurant Name
                      </label>

                      <input
                        type="text"
                        name="restaurantName"
                        placeholder="Restaurant Name"
                        value={formData.restaurantName}
                        onChange={handleChange}
                        style={styles.input}
                        required
                      />
                    </div>

                    <div style={styles.row}>
                      <div style={styles.formGroup}>
                        <label style={styles.label}>
                          Cuisine Type
                        </label>

                        <select
                          name="cuisineType"
                          value={formData.cuisineType}
                          onChange={handleChange}
                          style={styles.select}
                          required
                        >
                          <option value="">
                            Select Cuisine
                          </option>

                          <option value="Italian">
                            Italian
                          </option>

                          <option value="Chinese">
                            Chinese
                          </option>

                          <option value="Indian">
                            Indian
                          </option>

                          <option value="Mexican">
                            Mexican
                          </option>
                        </select>
                      </div>

                      <div style={styles.formGroup}>
                        <label style={styles.label}>City</label>

                        <input
                          type="text"
                          name="city"
                          placeholder="New York"
                          value={formData.city}
                          onChange={handleChange}
                          style={styles.input}
                        />
                      </div>
                    </div>

                    <div style={styles.formGroup}>
                      <label style={styles.label}>Address</label>

                      <input
                        type="text"
                        name="address"
                        placeholder="123 Main Street"
                        value={formData.address}
                        onChange={handleChange}
                        style={styles.input}
                        required
                      />
                    </div>
                  </>
                )}

                {role === 'rider' && (
                  <div style={styles.row}>
                    <div style={styles.formGroup}>
                      <label style={styles.label}>
                        Vehicle Type
                      </label>

                      <select
                        name="vehicleType"
                        value={formData.vehicleType}
                        onChange={handleChange}
                        style={styles.select}
                      >
                        <option value="bicycle">
                          Bicycle
                        </option>

                        <option value="motorcycle">
                          Motorcycle
                        </option>

                        <option value="car">Car</option>

                        <option value="scooter">
                          Scooter
                        </option>
                      </select>
                    </div>

                    <div style={styles.formGroup}>
                      <label style={styles.label}>
                        License Number
                      </label>

                      <input
                        type="text"
                        name="licenseNumber"
                        placeholder="DL-123456"
                        value={formData.licenseNumber}
                        onChange={handleChange}
                        style={styles.input}
                      />
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  style={styles.submitBtn}
                  disabled={loading}
                >
                  {loading
                    ? 'Creating Account...'
                    : 'Create Account'}
                </button>
              </form>
            </>
          )}

          <p style={styles.loginLink}>
            Already have an account?{' '}
            <Link to="/login" style={styles.signinLink}>
              Sign In
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    minHeight: '100vh',
    display: 'grid',
    gridTemplateColumns: '1.05fr 0.95fr',
    background: '#F1F5F9',
    fontFamily: 'Inter, sans-serif',
  },

  leftPanel: {
    background:
      'radial-gradient(circle at top right, rgba(255,107,53,0.16), transparent 25%), linear-gradient(135deg, #020617 0%, #0F172A 60%, #111827 100%)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '70px',
  },

  brandContent: {
    width: '100%',
    maxWidth: '520px',
  },

  logoBox: {
    width: '76px',
    height: '76px',
    borderRadius: '24px',
    background:
      'linear-gradient(135deg, #FF6B35 0%, #F97316 100%)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#FFFFFF',
    fontWeight: 800,
    fontSize: '1.3rem',
    marginBottom: '30px',
    boxShadow: '0 18px 40px rgba(249,115,22,0.35)',
  },

  brandTitle: {
    fontSize: '4rem',
    lineHeight: 1,
    fontWeight: 800,
    color: '#FFFFFF',
    marginBottom: '20px',
    letterSpacing: '-2px',
  },

  brandSubtitle: {
    color: '#CBD5E1',
    fontSize: '1.05rem',
    lineHeight: 1.9,
    maxWidth: '480px',
    marginBottom: '48px',
  },

  featureCard: {
    background: 'rgba(255,255,255,0.05)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: '28px',
    padding: '32px',
    backdropFilter: 'blur(12px)',
  },

  featureItem: {
    display: 'flex',
    gap: '16px',
    marginBottom: '28px',
  },

  featureDot: {
    width: '14px',
    height: '14px',
    borderRadius: '50%',
    background: '#FF6B35',
    marginTop: '7px',
    boxShadow: '0 0 18px rgba(255,107,53,0.7)',
  },

  featureTitle: {
    color: '#FFFFFF',
    marginBottom: '6px',
    fontSize: '1rem',
    fontWeight: 700,
  },

  featureText: {
    color: '#CBD5E1',
    lineHeight: 1.7,
    fontSize: '0.95rem',
  },

  rightPanel: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '40px',
  },

  formContainer: {
    width: '100%',
    maxWidth: '520px',
    background: '#FFFFFF',
    borderRadius: '32px',
    padding: '44px',
    border: '1px solid #E2E8F0',
    boxShadow: '0 24px 60px rgba(15,23,42,0.08)',
  },

  formTitle: {
    fontSize: '2.2rem',
    fontWeight: 800,
    color: '#0F172A',
    marginBottom: '8px',
    letterSpacing: '-1px',
  },

  formSubtitle: {
    color: '#64748B',
    marginBottom: '28px',
    fontSize: '0.98rem',
  },

  roleGrid: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '16px',
  },

  roleCard: {
    borderRadius: '22px',
    padding: '24px',
    background: '#FFFFFF',
    cursor: 'pointer',
    textAlign: 'left',
    transition: 'all 0.2s ease',
  },

  roleBadge: {
    width: '48px',
    height: '48px',
    borderRadius: '16px',
    background: '#FFF1EA',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#FF6B35',
    fontWeight: 800,
    marginBottom: '18px',
  },

  roleLabel: {
    fontSize: '1rem',
    fontWeight: 700,
    marginBottom: '8px',
  },

  roleDesc: {
    color: '#64748B',
    fontSize: '0.88rem',
    lineHeight: 1.6,
  },

  row: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '16px',
  },

  formGroup: {
    marginBottom: '20px',
  },

  label: {
    display: 'block',
    marginBottom: '10px',
    color: '#334155',
    fontWeight: 600,
    fontSize: '0.92rem',
  },

  inputWrapper: {
    position: 'relative',
  },

  inputIcon: {
    position: 'absolute',
    top: '50%',
    left: '16px',
    transform: 'translateY(-50%)',
    color: '#94A3B8',
  },

  input: {
    width: '100%',
    height: '56px',
    borderRadius: '18px',
    border: '1px solid #CBD5E1',
    background: '#F8FAFC',
    paddingLeft: '48px',
    paddingRight: '16px',
    fontSize: '0.95rem',
    outline: 'none',
    boxSizing: 'border-box',
  },

  select: {
    width: '100%',
    height: '56px',
    borderRadius: '18px',
    border: '1px solid #CBD5E1',
    background: '#F8FAFC',
    padding: '0 16px',
    fontSize: '0.95rem',
    outline: 'none',
  },

  eyeBtn: {
    position: 'absolute',
    top: '50%',
    right: '16px',
    transform: 'translateY(-50%)',
    border: 'none',
    background: 'transparent',
    color: '#94A3B8',
    cursor: 'pointer',
  },

  continueBtn: {
    width: '100%',
    height: '58px',
    marginTop: '24px',
    border: 'none',
    borderRadius: '18px',
    background:
      'linear-gradient(135deg, #FF6B35 0%, #F97316 100%)',
    color: '#FFFFFF',
    fontWeight: 700,
    fontSize: '1rem',
    cursor: 'pointer',
    boxShadow: '0 18px 35px rgba(249,115,22,0.28)',
  },

  submitBtn: {
    width: '100%',
    height: '58px',
    marginTop: '10px',
    border: 'none',
    borderRadius: '18px',
    background:
      'linear-gradient(135deg, #FF6B35 0%, #F97316 100%)',
    color: '#FFFFFF',
    fontWeight: 700,
    fontSize: '1rem',
    cursor: 'pointer',
    boxShadow: '0 18px 35px rgba(249,115,22,0.28)',
  },

  backBtn: {
    border: 'none',
    background: '#FFF1EA',
    color: '#EA580C',
    padding: '10px 14px',
    borderRadius: '14px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    marginBottom: '20px',
    cursor: 'pointer',
    fontWeight: 600,
  },

  errorBanner: {
    background: '#FEF2F2',
    border: '1px solid #FECACA',
    color: '#DC2626',
    padding: '14px 16px',
    borderRadius: '16px',
    marginBottom: '22px',
  },

  loginLink: {
    textAlign: 'center',
    marginTop: '28px',
    color: '#64748B',
    fontSize: '0.94rem',
  },

  signinLink: {
    color: '#FF6B35',
    fontWeight: 700,
    textDecoration: 'none',
  },
};

export default RegisterPage;