import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { customerAPI } from '../../services/api';
import {
  FiArrowLeft,
  FiPlus,
  FiMinus,
  FiShoppingCart,
  FiX,
  FiMapPin
} from 'react-icons/fi';

const RestaurantDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [restaurant, setRestaurant] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [orderPlacing, setOrderPlacing] = useState(false);

  const [deliveryAddress, setDeliveryAddress] = useState('');

  const fetchRestaurantData = useCallback(async () => {
    try {
      setLoading(true);
      const response = await customerAPI.getRestaurant(id);
      setRestaurant(response?.data?.restaurant || null);
      setMenuItems(response?.data?.menuItems || []);
      setCategories(response?.data?.categories || []);
    } catch (err) {
      console.error('Failed to fetch restaurant:', err);
      alert('Failed to load restaurant details.');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchRestaurantData();
  }, [fetchRestaurantData]);

  const addToCart = (item) => {
    setCart((prev) => {
      const existing = prev.find((cartItem) => cartItem.id === item.id);
      if (existing) {
        return prev.map((cartItem) =>
          cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    setCartOpen(true);
  };

  const removeFromCart = (itemId) => {
    setCart((prev) => {
      const existing = prev.find((cartItem) => cartItem.id === itemId);
      if (existing && existing.quantity > 1) {
        return prev.map((cartItem) =>
          cartItem.id === itemId ? { ...cartItem, quantity: cartItem.quantity - 1 } : cartItem
        );
      }
      return prev.filter((cartItem) => cartItem.id !== itemId);
    });
  };

  const cartSubtotal = cart.reduce((sum, item) => sum + Number(item.price || 0) * Number(item.quantity || 0), 0);
  const cartCount = cart.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  const deliveryFee = Number(restaurant?.delivery_fee || 250); // default 250
  const totalAmount = Number((cartSubtotal + deliveryFee).toFixed(2));

  const handlePlaceOrder = async () => {
    if (cart.length === 0) return alert('Your cart is empty.');
    if (!deliveryAddress.trim()) return alert('Please enter your delivery address.');

    setOrderPlacing(true);
    try {
      const orderData = {
        restaurantId: parseInt(id, 10),
        deliveryAddress: deliveryAddress.trim(),
        items: cart.map((item) => ({ menuItemId: item.id, quantity: item.quantity }))
      };

      await customerAPI.placeOrder(orderData);
      setCart([]);
      setCartOpen(false);
      setDeliveryAddress('');
      navigate('/customer/orders');
    } catch (err) {
      console.error('Order failed:', err);
      alert(err?.response?.data?.error || 'Order failed. Please try again.');
    } finally {
      setOrderPlacing(false);
    }
  };

  if (loading) {
    return (
      <div className="main-content">
        <div className="loading-overlay">
          <div className="spinner"></div>
          <p>Loading restaurant...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="main-content">
      <button className="btn btn-ghost" onClick={() => navigate(-1)} style={{ marginBottom: 16 }}>
        <FiArrowLeft /> Back
      </button>

      {/* Restaurant Header */}
      <div style={{ background: 'linear-gradient(135deg, #FFF3ED 0%, #FFE4D6 100%)', borderRadius: 16, padding: 32, display: 'flex', alignItems: 'center', gap: 24, marginBottom: 32 }}>
        <span style={{ fontSize: '4rem' }}>🍽️</span>
        <div style={{ flex: 1 }}>
          <h1>{restaurant?.name || 'Restaurant'}</h1>
          <p style={{ color: '#6B7280' }}>{restaurant?.cuisine_type || 'General'} Cuisine</p>
          <div style={{ display: 'flex', gap: 16, marginTop: 12, color: '#6B7280', fontSize: '0.9rem', flexWrap: 'wrap' }}>
            <span>⭐ {parseFloat(restaurant?.rating || 0).toFixed(1)}</span>
            <span>🕐 {restaurant?.estimated_delivery_time || 30} min</span>
            <span>🚚 {deliveryFee.toFixed(2)} delivery</span>
          </div>
        </div>
      </div>

      {/* Menu */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
        {menuItems.length > 0 ? (
          categories.map((category) => {
            const categoryItems = menuItems.filter((item) => categories.length === 1 ? true : String(item.category_id) === String(category.id));
            if (categoryItems.length === 0) return null;

            return (
              <div key={category.id}>
                <h3 style={{ marginBottom: 16, borderBottom: '2px solid #FFE4D6', paddingBottom: 8 }}>{category.name}</h3>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
                  {categoryItems.map((item) => <MenuItem key={item.id} item={item} onAdd={addToCart} />)}
                </div>
              </div>
            );
          })
        ) : (
          <div style={{ textAlign: 'center', padding: '40px' }}>
            <p style={{ color: '#9CA3AF' }}>No menu items available for this restaurant.</p>
          </div>
        )}
      </div>

      {/* Cart Button */}
      {cartCount > 0 && (
        <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 100 }}>
          <button className="btn btn-primary btn-lg shadow-lg" onClick={() => setCartOpen(true)}>
            <FiShoppingCart /> Cart ({cartCount}) · {totalAmount.toFixed(2)}
          </button>
        </div>
      )}

      {/* Cart Panel */}
      <div className={`cart-panel ${cartOpen ? 'open' : ''}`} style={{ position: 'fixed', right: cartOpen ? 0 : '-420px', top: 0, width: '390px', maxWidth: '100%', height: '100%', background: 'white', boxShadow: '-4px 0 15px rgba(0,0,0,0.1)', transition: '0.3s', zIndex: 1000, display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: 20, borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3>Your Order</h3>
          <button className="btn btn-ghost" onClick={() => setCartOpen(false)}><FiX /></button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: 20 }}>
          {cart.map((item) => (
            <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 15, gap: 12 }}>
              <div>
                <div style={{ fontWeight: 600 }}>{item.name}</div>
                <div style={{ fontSize: '0.8rem', color: '#6B7280' }}>{Number(item.price || 0).toFixed(2)} x {item.quantity}</div>
              </div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <button className="btn btn-sm" onClick={() => removeFromCart(item.id)}><FiMinus /></button>
                <span>{item.quantity}</span>
                <button className="btn btn-sm" onClick={() => addToCart(item)}><FiPlus /></button>
              </div>
            </div>
          ))}

          {/* Delivery Address */}
          <div style={{ marginTop: 24, paddingTop: 20, borderTop: '1px solid #eee' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 600, marginBottom: 8 }}>
              <FiMapPin /> Shipping / Delivery Address
            </label>
            <textarea
              className="form-input"
              rows="4"
              placeholder="Enter complete delivery address, house number, street, area, city..."
              value={deliveryAddress}
              onChange={(e) => setDeliveryAddress(e.target.value)}
              style={{ width: '100%', resize: 'vertical', padding: 12, borderRadius: 8, border: '1px solid #D1D5DB' }}
            />
          </div>
        </div>

        {/* Cart Summary */}
        <div style={{ padding: 20, background: '#F9FAFB', borderTop: '1px solid #eee' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span>Subtotal</span>
            <span>{cartSubtotal.toFixed(2)}</span>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
            <span>Delivery Fee</span>
            <span>{deliveryFee.toFixed(2)}</span>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16, fontWeight: 800, fontSize: '1.1rem' }}>
            <span>Total</span>
            <span>{totalAmount.toFixed(2)}</span>
          </div>

          <button className="btn btn-primary btn-lg w-full" onClick={handlePlaceOrder} disabled={orderPlacing}>
            {orderPlacing ? 'Processing...' : 'Checkout Now'}
          </button>
        </div>
      </div>
    </div>
  );
};

const MenuItem = ({ item, onAdd }) => (
  <div className="menu-item-card" style={{ background: '#fff', padding: 16, borderRadius: 12, border: '1px solid #E5E7EB', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
    <div>
      <h4 style={{ margin: '0 0 4px 0' }}>{item.name}</h4>
      <p style={{ fontSize: '0.85rem', color: '#6B7280', marginBottom: 12 }}>{item.description}</p>
    </div>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <span style={{ fontWeight: 700, color: '#F97316' }}>{parseFloat(item.price || 0).toFixed(2)}</span>
      <button className="btn btn-primary btn-sm" onClick={() => onAdd(item)}><FiPlus /> Add</button>
    </div>
  </div>
);

export default RestaurantDetail;