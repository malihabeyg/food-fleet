import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { customerAPI } from '../../services/api';
import { FiSearch, FiStar, FiClock, FiMapPin, FiTruck } from 'react-icons/fi';

const cuisineEmojis = {
  Italian: '🍝',
  Mexican: '🌮',
  Chinese: '🥡',
  Japanese: '🍣',
  Indian: '🍛',
  American: '🍔',
  Thai: '🍜',
  Mediterranean: '🥙',
  Korean: '🍱',
  General: '🍽️',
};

const CustomerDashboard = () => {
  const [restaurants, setRestaurants] = useState([]);
  const [search, setSearch] = useState('');
  const [cuisine, setCuisine] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchRestaurants();
  }, [search, cuisine]);

  const fetchRestaurants = async () => {
    try {
      setLoading(true);
      const params = {};
      if (search) params.search = search;
      if (cuisine) params.cuisine = cuisine;

      // This calls your Express backend: router.get('/restaurants', ctrl.getRestaurants)
      const response = await customerAPI.getRestaurants(params);
      
      // Ensure we set the array from the backend response
      setRestaurants(response.data.restaurants || []);
    } catch (err) {
      console.error('Failed to fetch restaurants from backend:', err);
      // We keep the array empty on error so you can debug the API failure
      setRestaurants([]);
    } finally {
      setLoading(false);
    }
  };

  const cuisines = ['Italian', 'Mexican', 'Chinese', 'Japanese', 'Indian', 'American', 'Thai', 'Mediterranean', 'Korean'];

  return (
    <div className="main-content">
      <div className="page-header">
        <div>
          <h1>🍔 Find Your Meal</h1>
          <p style={{ color: '#6B7280', marginTop: 4 }}>Discover restaurants near you</p>
        </div>
      </div>

      {/* Search and Filter Section */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
        <div className="search-bar" style={{ flex: 1, minWidth: 250 }}>
          <FiSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search restaurants or cuisines..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <select
          className="form-select"
          style={{ width: 180 }}
          value={cuisine}
          onChange={(e) => setCuisine(e.target.value)}
        >
          <option value="">All Cuisines</option>
          {cuisines.map((c) => (
            <option key={c} value={c}>
              {cuisineEmojis[c]} {c}
            </option>
          ))}
        </select>
      </div>

      {/* Quick Category Buttons */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>
        {cuisines.map((c) => (
          <button
            key={c}
            className={`btn btn-sm ${cuisine === c ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setCuisine(cuisine === c ? '' : c)}
          >
            {cuisineEmojis[c]} {c}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="loading-overlay">
          <div className="spinner"></div>
          <p>Loading restaurants from FoodFleet...</p>
        </div>
      ) : restaurants.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px', color: '#6B7280' }}>
          <h3>No restaurants found</h3>
          <p>Make sure your database has restaurants with "is_open = 1"</p>
        </div>
      ) : (
        <div className="restaurant-grid">
          {restaurants.map((restaurant) => (
            <div
              key={restaurant.id}
              className="restaurant-card"
              onClick={() => navigate(`/customer/restaurants/${restaurant.id}`)}
            >
              <div
                className="card-image"
                style={{
                  background: restaurant.is_open
                    ? 'linear-gradient(135deg, #FFF3ED 0%, #FFE4D6 100%)'
                    : 'linear-gradient(135deg, #F3F4F6 0%, #E5E7EB 100%)',
                }}
              >
                <span style={{ fontSize: '3.5rem' }}>
                  {cuisineEmojis[restaurant.cuisine_type] || '🍽️'}
                </span>

                <span className="cuisine-tag">{restaurant.cuisine_type}</span>

                {!restaurant.is_open && (
                  <div
                    style={{
                      position: 'absolute',
                      inset: 0,
                      background: 'rgba(0,0,0,0.5)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'white',
                      fontWeight: 700,
                      fontSize: '1.1rem',
                    }}
                  >
                    Closed
                  </div>
                )}
              </div>

              <div className="card-info">
                <h3>{restaurant.name}</h3>
                <div className="card-meta">
                  <span className="rating">⭐ {parseFloat(restaurant.rating || 0).toFixed(1)}</span>
                  <span className="dot"></span>
                  <span>
                    <FiClock size={12} /> {restaurant.estimated_delivery_time || 30} min
                  </span>
                  <span className="dot"></span>
                  <span>
                    <FiTruck size={12} /> ${parseFloat(restaurant.delivery_fee || 0).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CustomerDashboard;