import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { customerAPI } from '../../services/api';
import { FiRefreshCw, FiPackage } from 'react-icons/fi';

const statusSteps = ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered'];
const statusLabels = {
  pending: 'Confirmed',
  confirmed: 'Accepted',
  preparing: 'Preparing',
  out_for_delivery: 'On the Way',
  delivered: 'Delivered',
  ready: 'Ready',
  cancelled: 'Cancelled',
};
const statusIcons = {
  pending: '📝', confirmed: '✅', preparing: '👨‍🍳', out_for_delivery: '🚴', delivered: '🎉', ready: '📦', cancelled: '❌',
};

const CustomerOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('active');
  const navigate = useNavigate();

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const response = await customerAPI.getOrders();
      // Directly setting the state with backend data
      setOrders(response.data.orders || []);
    } catch (err) {
      console.error("Order fetch failed:", err);
      setOrders([]); // Set to empty array on error to avoid showing old demo data
    } finally {
      setLoading(false);
    }
  };

  // Filter logic based on your DB status values
  const activeOrders = orders.filter((o) => !['delivered', 'cancelled'].includes(o.status?.toLowerCase()));
  const pastOrders = orders.filter((o) => ['delivered', 'cancelled'].includes(o.status?.toLowerCase()));
  const displayOrders = activeTab === 'active' ? activeOrders : pastOrders;

  const getProgressPercent = (status) => {
    const idx = statusSteps.indexOf(status?.toLowerCase());
    return idx >= 0 ? (idx / (statusSteps.length - 1)) * 100 : 0;
  };

  return (
    <div className="main-content">
      <div className="page-header">
        <h1>📦 My Orders</h1>
        <button 
          className="btn btn-secondary btn-sm" 
          onClick={fetchOrders}
          disabled={loading}
        >
          <FiRefreshCw className={loading ? 'spin' : ''} /> Refresh
        </button>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        <button
          className={`btn ${activeTab === 'active' ? 'btn-primary' : 'btn-secondary'}`}
          onClick={() => setActiveTab('active')}
        >
          Active {activeOrders.length > 0 && `(${activeOrders.length})`}
        </button>
        <button
          className={`btn ${activeTab === 'past' ? 'btn-primary' : 'btn-secondary'}`}
          onClick={() => setActiveTab('past')}
        >
          Past Orders
        </button>
      </div>

      {loading ? (
        <div className="loading-overlay">
          <div className="spinner"></div>
          <p>Syncing with FoodFleet...</p>
        </div>
      ) : displayOrders.length === 0 ? (
        <div className="empty-state" style={{ textAlign: 'center', padding: '60px 20px' }}>
          <div style={{ fontSize: '4rem', marginBottom: 16 }}>{activeTab === 'active' ? '📭' : '📋'}</div>
          <h3>{activeTab === 'active' ? 'No active orders' : 'No past orders'}</h3>
          <p style={{ color: '#6B7280' }}>
            {activeTab === 'active' ? 'Hungry? Place an order to track it here.' : 'Your order history is empty.'}
          </p>
          <button className="btn btn-primary" style={{ marginTop: 24 }} onClick={() => navigate('/customer')}>
            Start Ordering
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {displayOrders.map((order) => (
            <div key={order.id} className="card" onClick={() => navigate(`/customer/orders/${order.id}`)}>
              <div className="card-body">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <h4 style={{ color: '#1F2937' }}>{order.restaurant_name || 'FoodFleet Partner'}</h4>
                    <span style={{ fontSize: '0.8rem', color: '#9CA3AF' }}>
                      #{String(order.id).padStart(5, '0')} · {new Date(order.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <span className={`badge badge-${order.status?.toLowerCase()}`}>
                      {statusIcons[order.status?.toLowerCase()] || '❓'} {statusLabels[order.status?.toLowerCase()] || order.status}
                    </span>
                    <div style={{ fontWeight: 800, marginTop: 4, color: '#F97316' }}>
                      ${parseFloat(order.total_amount || 0).toFixed(2)}
                    </div>
                  </div>
                </div>

                {/* Tracking UI */}
                {activeTab === 'active' && order.status !== 'cancelled' && (
                  <div className="order-progress" style={{ marginTop: 24 }}>
                    <div className="progress-line" style={{ width: `${getProgressPercent(order.status)}%` }}></div>
                    {statusSteps.map((step, idx) => (
                      <div
                        key={step}
                        className={`progress-step ${
                          statusSteps.indexOf(order.status?.toLowerCase()) >= idx ? 'completed' : ''
                        }`}
                      >
                        <div className="step-circle">
                          {statusSteps.indexOf(order.status?.toLowerCase()) > idx ? '✓' : statusIcons[step]}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CustomerOrders;