import React, { useState, useEffect } from 'react';
import { riderAPI } from '../../services/api';
import {
  FiTruck,
  FiDollarSign,
  FiPackage,
  FiStar,
  FiToggleLeft,
  FiToggleRight,
  FiPhone,
} from 'react-icons/fi';

const RiderDashboard = () => {
  const [profile, setProfile] = useState(null);
  const [stats, setStats] = useState(null);
  const [activeOrders, setActiveOrders] = useState([]);
  const [isOnline, setIsOnline] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      setLoading(true);

      const [profileRes, statsRes, ordersRes] = await Promise.all([
        riderAPI.getProfile(),
        riderAPI.getStats(),
        riderAPI.getActiveOrders(),
      ]);

      setProfile(profileRes.data.rider);
      setStats(statsRes.data);
      setActiveOrders(ordersRes.data.orders || []);
      setIsOnline(profileRes.data.rider?.is_online || false);
    } catch (err) {
      console.error('Rider dashboard error:', err);

      setProfile({
        name: 'Alex Rider',
        vehicle_type: 'motorcycle',
        is_online: false,
      });

      setStats({
        todayDeliveries: 0,
        todayEarnings: 0,
        weeklyEarnings: [],
      });

      setActiveOrders([]);
    } finally {
      setLoading(false);
    }
  };

  const toggleOnline = async () => {
    const newState = !isOnline;

    try {
      await riderAPI.updateAvailability({ isOnline: newState });
      setIsOnline(newState);
    } catch (err) {
      console.error('Toggle availability error:', err);
      alert(err.response?.data?.error || 'Unable to update availability');
    }
  };

  const confirmPickup = async (orderId) => {
    try {
      await riderAPI.confirmPickup(orderId);

      setActiveOrders((prev) =>
        prev.map((order) =>
          order.id === orderId
            ? { ...order, status: 'picked_up' }
            : order
        )
      );
    } catch (err) {
      console.error('Confirm pickup error:', err);
      alert(err.response?.data?.error || 'Unable to confirm pickup');
    }
  };

  const confirmDelivery = async (orderId) => {
    try {
      await riderAPI.confirmDelivery(orderId);

      setActiveOrders((prev) =>
        prev.filter((order) => order.id !== orderId)
      );

      fetchDashboard();
    } catch (err) {
      console.error('Confirm delivery error:', err);
      alert(err.response?.data?.error || 'Unable to confirm delivery');
    }
  };

  const handleStatusChange = async (order, nextStatus) => {
    if (!nextStatus || nextStatus === order.status) return;

    if (nextStatus === 'picked_up') {
      await confirmPickup(order.id);
      return;
    }

    if (nextStatus === 'delivered') {
      await confirmDelivery(order.id);
      return;
    }
  };

  const getStatusLabel = (status) => {
    if (status === 'out_for_delivery') return '📦 Ready for Pickup';
    if (status === 'picked_up') return '🚴 Picked Up';
    return status;
  };

  return (
    <div className="main-content">
      <div className="page-header">
        <h1>🚴 Rider Dashboard</h1>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span
            style={{
              fontSize: '0.9rem',
              fontWeight: 600,
              color: isOnline ? '#10B981' : '#6B7280',
            }}
          >
            {isOnline ? '🟢 Online' : '⚫ Offline'}
          </span>

          <button
            className={`btn ${isOnline ? 'btn-success' : 'btn-secondary'}`}
            onClick={toggleOnline}
          >
            {isOnline ? <FiToggleRight /> : <FiToggleLeft />}
            {isOnline ? ' Go Offline' : ' Go Online'}
          </button>
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon orange">
            <FiTruck />
          </div>
          <div className="stat-content">
            <div className="stat-value">{stats?.todayDeliveries || 0}</div>
            <div className="stat-label">Today's Deliveries</div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon green">
            <FiDollarSign />
          </div>
          <div className="stat-content">
            <div className="stat-value">
              ${parseFloat(stats?.todayEarnings || 0).toFixed(2)}
            </div>
            <div className="stat-label">Today's Earnings</div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon blue">
            <FiPackage />
          </div>
          <div className="stat-content">
            <div className="stat-value">
              {profile?.total_deliveries || 0}
            </div>
            <div className="stat-label">Total Deliveries</div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon yellow">
            <FiStar />
          </div>
          <div className="stat-content">
            <div className="stat-value">
              {parseFloat(profile?.rating || 0).toFixed(1)}
            </div>
            <div className="stat-label">
              Rating ({profile?.review_count || 0} reviews)
            </div>
          </div>
        </div>
      </div>

      <div className="card" style={{ marginBottom: 24 }}>
        <div className="card-header">
          <h3>🚀 Active Deliveries</h3>
          <span className="badge badge-active">
            {activeOrders.length} active
          </span>
        </div>

        <div className="card-body">
          {loading ? (
            <div className="loading-overlay">
              <div className="spinner"></div>
            </div>
          ) : activeOrders.length === 0 ? (
            <div className="empty-state" style={{ padding: 30 }}>
              <div className="empty-icon">📭</div>
              <h4>No active deliveries</h4>
              <p>Go online to start receiving delivery assignments</p>
            </div>
          ) : (
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: 16,
              }}
            >
              {activeOrders.map((order) => (
                <div
                  key={order.id}
                  style={{
                    padding: 20,
                    border: '2px solid #E5E7EB',
                    borderRadius: 12,
                    borderLeft: `4px solid ${
                      order.status === 'picked_up' ? '#3B82F6' : '#10B981'
                    }`,
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'flex-start',
                      marginBottom: 16,
                    }}
                  >
                    <div>
                      <h4>Order #{String(order.id).slice(0, 8)}</h4>
                      <div
                        style={{
                          fontSize: '0.85rem',
                          color: '#6B7280',
                        }}
                      >
                        {order.restaurant_name}
                      </div>
                    </div>

                    <span className={`badge badge-${order.status}`}>
                      {getStatusLabel(order.status)}
                    </span>
                  </div>

                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: '1fr 1fr',
                      gap: 16,
                      marginBottom: 16,
                    }}
                  >
                    <div
                      style={{
                        background: '#F0FDF4',
                        padding: 12,
                        borderRadius: 8,
                      }}
                    >
                      <div
                        style={{
                          fontSize: '0.75rem',
                          fontWeight: 600,
                          color: '#10B981',
                          marginBottom: 4,
                        }}
                      >
                        📍 PICKUP
                      </div>

                      <div
                        style={{
                          fontSize: '0.85rem',
                          fontWeight: 600,
                        }}
                      >
                        {order.restaurant_name}
                      </div>

                      <div
                        style={{
                          fontSize: '0.8rem',
                          color: '#6B7280',
                        }}
                      >
                        {order.restaurant_address}
                      </div>

                      <div
                        style={{
                          fontSize: '0.8rem',
                          color: '#6B7280',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 4,
                        }}
                      >
                        <FiPhone size={12} />
                        {order.restaurant_phone}
                      </div>
                    </div>

                    <div
                      style={{
                        background: '#EFF6FF',
                        padding: 12,
                        borderRadius: 8,
                      }}
                    >
                      <div
                        style={{
                          fontSize: '0.75rem',
                          fontWeight: 600,
                          color: '#3B82F6',
                          marginBottom: 4,
                        }}
                      >
                        🏠 DELIVERY
                      </div>

                      <div
                        style={{
                          fontSize: '0.85rem',
                          fontWeight: 600,
                        }}
                      >
                        Customer Address
                      </div>

                      <div
                        style={{
                          fontSize: '0.8rem',
                          color: '#6B7280',
                        }}
                      >
                        {order.delivery_address}
                      </div>
                    </div>
                  </div>

                  <div style={{ marginBottom: 16 }}>
                    <div
                      style={{
                        fontSize: '0.8rem',
                        fontWeight: 600,
                        marginBottom: 4,
                      }}
                    >
                      Items:
                    </div>

                    {(order.items || []).length === 0 ? (
                      <span
                        style={{
                          fontSize: '0.8rem',
                          color: '#6B7280',
                        }}
                      >
                        No items found
                      </span>
                    ) : (
                      (order.items || []).map((item, idx) => (
                        <span
                          key={idx}
                          style={{
                            fontSize: '0.8rem',
                            color: '#6B7280',
                            marginRight: 12,
                          }}
                        >
                          {item.quantity}x {item.name}
                        </span>
                      ))
                    )}
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      gap: 8,
                      justifyContent: 'flex-end',
                      alignItems: 'center',
                    }}
                  >
                    <select
                      value={order.status}
                      onChange={(e) =>
                        handleStatusChange(order, e.target.value)
                      }
                      style={{
                        padding: '9px 12px',
                        borderRadius: 8,
                        border: '1px solid #D1D5DB',
                        fontWeight: 600,
                        background: '#FFFFFF',
                        cursor: 'pointer',
                      }}
                    >
                      <option value="out_for_delivery">
                        Ready for Pickup
                      </option>
                      <option value="picked_up">
                        Picked Up / Out for Delivery
                      </option>
                      <option value="delivered">
                        Delivered
                      </option>
                    </select>

                    {order.status === 'out_for_delivery' && (
                      <button
                        className="btn btn-success"
                        onClick={() => confirmPickup(order.id)}
                      >
                        ✅ Confirm Pickup
                      </button>
                    )}

                    {order.status === 'picked_up' && (
                      <button
                        className="btn btn-primary"
                        onClick={() => confirmDelivery(order.id)}
                      >
                        🎉 Mark Delivered
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h3>💰 Weekly Earnings</h3>
        </div>

        <div className="card-body">
          {!stats?.weeklyEarnings || stats.weeklyEarnings.length === 0 ? (
            <div
              style={{
                textAlign: 'center',
                color: '#6B7280',
                padding: 20,
              }}
            >
              No earnings data for this week yet.
            </div>
          ) : (
            <div
              style={{
                display: 'flex',
                gap: 8,
                alignItems: 'flex-end',
                height: 150,
              }}
            >
              {stats.weeklyEarnings.map((day, idx) => {
                const maxEarnings = Math.max(
                  ...stats.weeklyEarnings.map((d) =>
                    parseFloat(d.earnings || 0)
                  )
                );

                const height =
                  maxEarnings > 0
                    ? (parseFloat(day.earnings || 0) / maxEarnings) * 100
                    : 0;

                return (
                  <div
                    key={idx}
                    style={{
                      flex: 1,
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: 4,
                    }}
                  >
                    <span
                      style={{
                        fontSize: '0.7rem',
                        fontWeight: 600,
                      }}
                    >
                      ${parseFloat(day.earnings || 0).toFixed(0)}
                    </span>

                    <div
                      style={{
                        width: '100%',
                        height: `${height}%`,
                        background:
                          'linear-gradient(180deg, #FF6B35 0%, #FF8F65 100%)',
                        borderRadius: '4px 4px 0 0',
                        minHeight: 4,
                        transition: 'height 0.3s ease',
                      }}
                    ></div>

                    <span
                      style={{
                        fontSize: '0.65rem',
                        color: '#6B7280',
                      }}
                    >
                      {new Date(day.date).toLocaleDateString('en', {
                        weekday: 'short',
                      })}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RiderDashboard;