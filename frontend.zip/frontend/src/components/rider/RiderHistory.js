// src/pages/rider/RiderHistory.jsx

import React, { useState, useEffect } from 'react';
import { riderAPI } from '../../services/api';
import { FiMapPin, FiRefreshCw } from 'react-icons/fi';

const RiderHistory = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    setLoading(true);

    try {
      const response = await riderAPI.getOrderHistory();

      console.log('Delivery History:', response.data);

      setOrders(response.data.orders || []);
    } catch (err) {
      console.error('Rider history fetch error:', err);
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  // Rider gets 70% of delivery fee
  const totalEarnings = orders.reduce(
    (sum, order) => sum + parseFloat(order.delivery_fee || 0) * 0.7,
    0
  );

  return (
    <div className="main-content">
      <div className="page-header">
        <h1>📋 Delivery History</h1>

        <div
          style={{
            display: 'flex',
            gap: 12,
            alignItems: 'center',
          }}
        >
          <div
            style={{
              background: '#ECFDF5',
              padding: '8px 16px',
              borderRadius: 8,
              color: '#10B981',
              fontWeight: 600,
            }}
          >
            💰 Total Earnings: ${totalEarnings.toFixed(2)}
          </div>

          <button
            className="btn btn-secondary btn-sm"
            onClick={fetchHistory}
          >
            <FiRefreshCw />
            Refresh
          </button>
        </div>
      </div>

      {loading ? (
        <div className="loading-overlay">
          <div className="spinner"></div>
        </div>
      ) : orders.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📭</div>
          <h3>No delivery history</h3>
          <p>Completed deliveries will appear here</p>
        </div>
      ) : (
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Order #</th>
                <th>Restaurant</th>
                <th>Delivery Address</th>
                <th>Delivered At</th>
                <th>Order Total</th>
                <th>Your Earnings</th>
              </tr>
            </thead>

            <tbody>
              {orders.map((order) => (
                <tr key={order.id}>
                  <td
                    style={{
                      fontWeight: 600,
                      fontFamily: 'monospace',
                    }}
                  >
                    #{String(order.id).slice(0, 8)}
                  </td>

                  <td>{order.restaurant_name}</td>

                  <td style={{ fontSize: '0.85rem' }}>
                    <FiMapPin size={12} /> {order.delivery_address}
                  </td>

                  <td
                    style={{
                      fontSize: '0.85rem',
                      color: '#6B7280',
                    }}
                  >
                    {order.actual_delivery_time
                      ? new Date(
                          order.actual_delivery_time
                        ).toLocaleString()
                      : order.created_at
                      ? new Date(order.created_at).toLocaleString()
                      : '—'}
                  </td>

                  <td style={{ color: '#6B7280' }}>
                    $
                    {parseFloat(order.total_amount || 0).toFixed(2)}
                  </td>

                  <td
                    style={{
                      fontWeight: 600,
                      color: '#10B981',
                    }}
                  >
                    $
                    {(
                      parseFloat(order.delivery_fee || 0) * 0.7
                    ).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RiderHistory;