import React, { useState, useEffect } from 'react';
import { restaurantAPI } from '../../services/api';
import { FiShoppingBag, FiDollarSign, FiClock, FiTrendingUp, FiPackage } from 'react-icons/fi';

const RestaurantDashboard = () => {
  const [stats, setStats] = useState(null);
  const [recentOrders, setRecentOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const [statsRes, ordersRes] = await Promise.all([
        restaurantAPI.getStats(),
        restaurantAPI.getOrders({ limit: 5 })
      ]);

      // FIX: Flexible extraction matching Admin portal pattern
      const statsData = statsRes.data?.data || statsRes.data;
      const ordersData = ordersRes.data?.data?.orders || ordersRes.data?.orders || [];

      setStats(statsData);
      setRecentOrders(ordersData);
    } catch (err) {
      console.error('Dashboard error:', err.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  const statusLabels = {
    pending: '⏳ New',
    confirmed: '✅ Confirmed',
    preparing: '👨‍🍳 Preparing',
    ready: '📦 Ready',
    out_for_delivery: '🚴 Out for Delivery',
    delivered: '✅ Delivered',
    cancelled: '❌ Cancelled'
  };

  if (loading) return <div className="main-content"><h3>Loading dashboard...</h3></div>;

  return (
    <div className="main-content">
      <div className="page-header"><h1>🍽️ Restaurant Dashboard</h1></div>
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon orange"><FiShoppingBag /></div>
          <div>
            <div className="stat-value">{stats?.todayOrders || 0}</div>
            <div className="stat-label">Today's Orders</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon green"><FiDollarSign /></div>
          <div>
            <div className="stat-value">${Number(stats?.todayRevenue || stats?.totalRevenue || 0).toFixed(2)}</div>
            <div className="stat-label">Total Revenue</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue"><FiPackage /></div>
          <div>
            <div className="stat-value">{stats?.totalOrders || 0}</div>
            <div className="stat-label">Total Orders</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon red"><FiClock /></div>
          <div>
            <div className="stat-value">{stats?.pendingOrders || 0}</div>
            <div className="stat-label">Pending Orders</div>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24 }}>
        <div className="card">
          <div className="card-header">
            <h3>Recent Orders</h3>
            <a href="/restaurant/orders">View All →</a>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table className="table">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Customer</th>
                  <th>Status</th>
                  <th>Amount</th>
                  <th>Time</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order) => (
                  <tr key={order.id}>
                    <td style={{ fontFamily: 'monospace' }}>#{String(order.id).slice(0, 8)}</td>
                    {/* FIX: Using customer_name from joined User table */}
                    <td>{order.customer_name || 'Guest'}</td> 
                    <td><span className={`badge badge-${order.status}`}>{statusLabels[order.status]}</span></td>
                    <td style={{ fontWeight: 600 }}>${Number(order.total_amount || 0).toFixed(2)}</td>
                    <td style={{ fontSize: 12, color: '#6B7280' }}>
                      {order.created_at ? new Date(order.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <div className="card-header"><h3>Popular Items</h3><FiTrendingUp /></div>
          <div className="card-body">
            {(stats?.popularItems || []).map((item, idx) => (
              <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid #eee' }}>
                <div>
                  <div style={{ fontWeight: 600 }}>{item.name}</div>
                  <div style={{ fontSize: 12, color: '#6B7280' }}>{item.total_ordered} orders</div>
                </div>
                <div className="rank-badge">#{idx + 1}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantDashboard;