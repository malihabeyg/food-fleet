import React, { useState, useEffect } from 'react';
import { restaurantAPI } from '../../services/api';
import { FiRefreshCw } from 'react-icons/fi';

const RestaurantOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [updatingId, setUpdatingId] = useState(null);

  useEffect(() => {
    fetchOrders();
  }, [statusFilter]);

  // ================= FETCH ORDERS =================
  const fetchOrders = async () => {
    setLoading(true);

    try {
      const params = {};

      if (statusFilter) {
        params.status = statusFilter;
      }

      const response = await restaurantAPI.getOrders(params);

      // Flexible extraction
      const result =
        response?.data?.data?.orders ||
        response?.data?.orders ||
        response?.data ||
        [];

      setOrders(Array.isArray(result) ? result : []);

    } catch (err) {
      console.error('Orders fetch error:', err);
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  // ================= UPDATE STATUS =================
  const updateOrderStatus = async (orderId, newStatus) => {
    setUpdatingId(orderId);

    try {
      await restaurantAPI.updateOrderStatus(orderId, newStatus);

      // Refresh orders
      await fetchOrders();

    } catch (err) {
      console.error('Status update error:', err);
    } finally {
      setUpdatingId(null);
    }
  };

  // ================= STATUS CONFIG =================
  const statusConfig = {
    pending: {
      label: 'New Order',
      badge: 'badge-pending',
      icon: '🔔',
    },
    confirmed: {
      label: 'Confirmed',
      badge: 'badge-confirmed',
      icon: '✅',
    },
    preparing: {
      label: 'Preparing',
      badge: 'badge-preparing',
      icon: '👨‍🍳',
    },
    ready: {
      label: 'Ready',
      badge: 'badge-ready',
      icon: '📦',
    },
    out_for_delivery: {
      label: 'Delivery',
      badge: 'badge-out_for_delivery',
      icon: '🚴',
    },
    delivered: {
      label: 'Delivered',
      badge: 'badge-delivered',
      icon: '✅',
    },
    cancelled: {
      label: 'Cancelled',
      badge: 'badge-cancelled',
      icon: '❌',
    },
  };

  const filters = [
    { label: 'All', value: '' },
    { label: 'New', value: 'pending' },
    { label: 'Confirmed', value: 'confirmed' },
    { label: 'Preparing', value: 'preparing' },
    { label: 'Ready', value: 'ready' },
    { label: 'Delivery', value: 'out_for_delivery' },
  ];

  return (
    <div className="main-content">

      {/* HEADER */}
      <div className="page-header">
        <h1>📦 Orders</h1>

        <button
          className="btn btn-secondary btn-sm"
          onClick={fetchOrders}
        >
          <FiRefreshCw /> Refresh
        </button>
      </div>

      {/* FILTERS */}
      <div
        style={{
          display: 'flex',
          gap: 8,
          marginBottom: 20,
          flexWrap: 'wrap',
        }}
      >
        {filters.map((f) => (
          <button
            key={f.value}
            className={`btn btn-sm ${
              statusFilter === f.value
                ? 'btn-primary'
                : 'btn-secondary'
            }`}
            onClick={() => setStatusFilter(f.value)}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* LOADING */}
      {loading ? (
        <div className="loading-overlay">
          <div className="spinner"></div>
        </div>
      ) : orders.length === 0 ? (
        <div className="empty-state">
          <h3>No orders found</h3>
        </div>
      ) : (
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: 16,
          }}
        >
          {orders.map((order, index) => {

            // SAFE ID HANDLING
            const orderId =
              order?._id ||
              order?.id ||
              `temp-${index}`;

            const orderIdString = String(orderId);

            const config =
              statusConfig[order?.status] || {};

            const isUpdating =
              updatingId === orderId;

            return (
              <div
                key={orderIdString}
                className="card"
                style={{
                  borderLeft: `4px solid ${
                    order?.status === 'pending'
                      ? '#F59E0B'
                      : order?.status === 'preparing'
                      ? '#F77F00'
                      : '#10B981'
                  }`,
                }}
              >
                <div className="card-body">

                  {/* HEADER */}
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                    }}
                  >
                    <div>

                      {/* FIXED SLICE ERROR */}
                      <h4>
                        Order #
                        {orderIdString.slice(0, 8)}
                      </h4>

                      <span
                        className={`badge ${config.badge || ''}`}
                      >
                        {config.icon || '📦'}{' '}
                        {config.label || order?.status}
                      </span>

                      <div
                        style={{
                          fontSize: 12,
                          color: '#666',
                          marginTop: 4,
                        }}
                      >
                        {order?.delivery_address ||
                          'No address'}
                      </div>
                    </div>

                    <div style={{ fontWeight: 700 }}>
                      $
                      {Number(
                        order?.total_amount || 0
                      ).toFixed(2)}
                    </div>
                  </div>

                  {/* CUSTOMER */}
                  <div style={{ marginTop: 10 }}>
                    👤{' '}
                    {order?.customer_first_name ||
                      'Guest'}{' '}
                    {order?.customer_last_name || ''}
                  </div>

                  {/* ITEMS */}
                  <div style={{ marginTop: 10 }}>
                    {(order?.items || []).map(
                      (item, idx) => (
                        <div
                          key={idx}
                          style={{
                            display: 'flex',
                            justifyContent:
                              'space-between',
                            marginBottom: 4,
                          }}
                        >
                          <span>
                            {item?.quantity || 0}x{' '}
                            {item?.name ||
                              'Unknown Item'}
                          </span>

                          <span>
                            $
                            {Number(
                              item?.total_price || 0
                            ).toFixed(2)}
                          </span>
                        </div>
                      )
                    )}
                  </div>
{/* ACTIONS */}
<div
  style={{
    marginTop: 12,
    display: 'flex',
    gap: 8,
    flexWrap: 'wrap',
  }}
>

  {/* PENDING → CONFIRMED */}
  {order?.status === 'pending' && (
    <>
      <button
        className="btn btn-success btn-sm"
        disabled={isUpdating}
        onClick={() =>
          updateOrderStatus(orderId, 'confirmed')
        }
      >
        {isUpdating ? 'Updating...' : 'Accept'}
      </button>

      <button
        className="btn btn-danger btn-sm"
        disabled={isUpdating}
        onClick={() =>
          updateOrderStatus(orderId, 'cancelled')
        }
      >
        {isUpdating ? 'Updating...' : 'Reject'}
      </button>
    </>
  )}

  {/* CONFIRMED → PREPARING */}
  {order?.status === 'confirmed' && (
    <button
      className="btn btn-warning btn-sm"
      disabled={isUpdating}
      onClick={() =>
        updateOrderStatus(orderId, 'preparing')
      }
    >
      {isUpdating ? 'Updating...' : 'Start Preparing'}
    </button>
  )}

  {/* PREPARING → READY */}
  {order?.status === 'preparing' && (
    <button
      className="btn btn-primary btn-sm"
      disabled={isUpdating}
      onClick={() =>
        updateOrderStatus(orderId, 'ready')
      }
    >
      {isUpdating ? 'Updating...' : 'Mark Ready'}
    </button>
  )}
{/* READY → OUT FOR DELIVERY */}
{order?.status === 'ready' && (
  <button
    className="btn btn-info btn-sm"
    disabled={isUpdating}
    onClick={async () => {

      await updateOrderStatus(
        orderId,
        'out_for_delivery'
      );

      alert('Order assigned to rider successfully');
    }}
  >
    {isUpdating
      ? 'Updating...'
      : 'Send To Delivery'}
  </button>
)}
  {/* CANCELLED */}
  {order?.status === 'cancelled' && (
    <div
      style={{
        color: '#EF4444',
        fontWeight: 600,
      }}
    >
      ❌ Cancelled
    </div>
  )}

</div>
  </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default RestaurantOrders;