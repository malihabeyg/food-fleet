import React, { useState, useEffect } from 'react';
import { restaurantAPI } from '../../services/api';
import { FiPlus, FiEdit2, FiTrash2, FiToggleLeft, FiToggleRight, FiSearch } from 'react-icons/fi';

const MenuManagement = () => {
  const [menuItems, setMenuItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('');

  const [form, setForm] = useState({
    name: '', description: '', price: '', categoryId: '', isAvailable: true,
    isPopular: false, preparationTime: 15, isVegetarian: false, isVegan: false,
  });

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    try {
      const [menuRes, catRes] = await Promise.all([
        restaurantAPI.getMenu(),
        restaurantAPI.getCategories(),
      ]);
      setMenuItems(menuRes.data || []);
      setCategories(catRes.data || []);
    } catch (err) {
      console.error(err);
      setMenuItems([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      const payload = {
        name: form.name, 
        description: form.description, 
        price: form.price,
        category_id: form.categoryId, 
        is_available: form.isAvailable,
        is_popular: form.isPopular, 
        preparation_time: form.preparationTime,
        is_vegetarian: form.isVegetarian, 
        is_vegan: form.isVegan,
      };

      if (editingItem) {
        await restaurantAPI.updateMenuItem(editingItem.id, payload);
      } else {
        await restaurantAPI.addMenuItem(payload);
      }
      await fetchMenu();
      setShowModal(false);
      setEditingItem(null);
      resetForm();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure?')) return;
    try {
      await restaurantAPI.deleteMenuItem(id);
      setMenuItems(prev => prev.filter(i => i.id !== id));
    } catch (err) { console.error(err); }
  };

  const toggleAvailability = async (item) => {
    try {
      await restaurantAPI.updateMenuItem(item.id, { is_available: !item.is_available });
      setMenuItems(prev => prev.map(i => i.id === item.id ? { ...i, is_available: !i.is_available } : i));
    } catch (err) { console.error(err); }
  };

  const resetForm = () => setForm({
    name: '', description: '', price: '', categoryId: '', isAvailable: true,
    isPopular: false, preparationTime: 15, isVegetarian: false, isVegan: false,
  });

  const openEdit = (item) => {
    setEditingItem(item);
    setForm({
      name: item.name, 
      description: item.description || '', 
      price: item.price,
      categoryId: item.category_id || '', 
      isAvailable: item.is_available,
      isPopular: item.is_popular, 
      preparationTime: item.preparation_time,
      isVegetarian: item.is_vegetarian, 
      isVegan: item.is_vegan,
    });
    setShowModal(true);
  };

  const filteredItems = menuItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = filterCategory ? String(item.category_id) === String(filterCategory) : true;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="main-content">
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h1 style={{ margin: 0 }}>📋 Menu Management</h1>
        <button className="btn btn-primary" onClick={() => { resetForm(); setEditingItem(null); setShowModal(true); }}>
          <FiPlus /> Add Item
        </button>
      </div>

      {/* Filter Bar */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
        <div className="search-bar" style={{ flex: 1, display: 'flex', alignItems: 'center', border: '1px solid #ddd', padding: '8px 12px', borderRadius: '6px', background: 'white' }}>
          <FiSearch style={{ marginRight: '8px', color: '#888' }} />
          <input 
            style={{ border: 'none', outline: 'none', width: '100%' }}
            placeholder="Search menu..." 
            value={search} 
            onChange={(e) => setSearch(e.target.value)} 
          />
        </div>
        <select 
          style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd', background: 'white' }}
          value={filterCategory} 
          onChange={(e) => setFilterCategory(e.target.value)}
        >
          <option value="">All Categories</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {/* Table */}
      {loading ? <div>Loading...</div> : (
        <table className="table" style={{ width: '100%', borderCollapse: 'collapse', background: 'white', borderRadius: '8px', overflow: 'hidden' }}>
          <thead>
            <tr style={{ background: '#f8f9fa', borderBottom: '2px solid #eee' }}>
              <th style={{ textAlign: 'left', padding: '12px' }}>Item</th>
              <th style={{ padding: '12px' }}>Category</th>
              <th style={{ padding: '12px' }}>Price</th>
              <th style={{ padding: '12px' }}>Prep</th>
              <th style={{ padding: '12px' }}>Status</th>
              <th style={{ padding: '12px' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredItems.map(item => (
              <tr key={item.id} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '12px' }}>
                  <div style={{ fontWeight: 'bold' }}>{item.name}</div>
                  <div style={{ fontSize: '12px', color: '#666' }}>{item.description}</div>
                </td>
                <td style={{ textAlign: 'center', padding: '12px' }}>{item.category_name || '-'}</td>
                <td style={{ textAlign: 'center', padding: '12px' }}>${Number(item.price).toFixed(2)}</td>
                <td style={{ textAlign: 'center', padding: '12px' }}>{item.preparation_time} min</td>
                <td style={{ textAlign: 'center', padding: '12px' }}>
                  <span style={{ color: item.is_available ? '#27ae60' : '#e74c3c', fontWeight: 500 }}>
                    {item.is_available ? 'Available' : 'Unavailable'}
                  </span>
                </td>
                <td style={{ textAlign: 'center', padding: '12px' }}>
                  <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
                    <button style={{ background: 'none', border: 'none', cursor: 'pointer' }} onClick={() => toggleAvailability(item)}>
                      {item.is_available ? <FiToggleRight color="#27ae60" size={20} /> : <FiToggleLeft color="#95a5a6" size={20} />}
                    </button>
                    <button style={{ background: 'none', border: 'none', cursor: 'pointer' }} onClick={() => openEdit(item)}>
                      <FiEdit2 color="#3498db" size={18} />
                    </button>
                    <button style={{ background: 'none', border: 'none', cursor: 'pointer' }} onClick={() => handleDelete(item.id)}>
                      <FiTrash2 color="#e74c3c" size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* FIXED MODAL OVERLAY */}
      {showModal && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.6)', display: 'flex',
          alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: '20px'
        }}>
          <div style={{
            backgroundColor: 'white', borderRadius: '12px', width: '100%',
            maxWidth: '500px', boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
            display: 'flex', flexDirection: 'column', overflow: 'hidden'
          }}>
            {/* Header */}
            <div style={{
              padding: '20px', borderBottom: '1px solid #eee', display: 'flex',
              justifyContent: 'space-between', alignItems: 'center'
            }}>
              <h3 style={{ margin: 0, fontSize: '1.2rem', color: '#333' }}>
                {editingItem ? 'Edit Menu Item' : 'Add New Item'}
              </h3>
              <button 
                onClick={() => setShowModal(false)}
                style={{ border: 'none', background: 'none', fontSize: '24px', cursor: 'pointer', color: '#888' }}
              >
                &times;
              </button>
            </div>

            {/* Body */}
            <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#555' }}>Item Name</label>
                <input 
                  style={{ padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                  value={form.name} 
                  onChange={e => setForm({ ...form, name: e.target.value })} 
                  placeholder="e.g. Cappuccino" 
                />
              </div>

              <div style={{ display: 'flex', gap: '16px' }}>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#555' }}>Category</label>
                  <select 
                    style={{ padding: '10px', borderRadius: '6px', border: '1px solid #ddd', background: 'white' }}
                    value={form.categoryId} 
                    onChange={e => setForm({ ...form, categoryId: e.target.value })}
                  >
                    <option value="">Select Category</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#555' }}>Price ($)</label>
                  <input 
                    type="number" 
                    style={{ padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                    value={form.price} 
                    onChange={e => setForm({ ...form, price: e.target.value })} 
                  />
                </div>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#555' }}>Description</label>
                <textarea 
                  style={{ padding: '10px', borderRadius: '6px', border: '1px solid #ddd', resize: 'vertical', fontFamily: 'inherit' }}
                  value={form.description} 
                  onChange={e => setForm({ ...form, description: e.target.value })} 
                  rows="2" 
                  placeholder="Describe the dish..."
                />
              </div>

              <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-end' }}>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <label style={{ fontSize: '13px', fontWeight: 'bold', color: '#555' }}>Prep Time (min)</label>
                  <input 
                    type="number" 
                    style={{ padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                    value={form.preparationTime} 
                    onChange={e => setForm({ ...form, preparationTime: e.target.value })} 
                  />
                </div>
                <label style={{ flex: 1, display: 'flex', alignItems: 'center', gap: '8px', paddingBottom: '12px', fontSize: '14px', cursor: 'pointer' }}>
                  <input type="checkbox" checked={form.isAvailable} onChange={e => setForm({ ...form, isAvailable: e.target.checked })} />
                  Available for Sale
                </label>
              </div>

              <div style={{ display: 'flex', gap: '15px', padding: '12px', background: '#f8f9fa', borderRadius: '8px', flexWrap: 'wrap' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', cursor: 'pointer' }}>
                  <input type="checkbox" checked={form.isVegetarian} onChange={e => setForm({...form, isVegetarian: e.target.checked})} /> Veg
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', cursor: 'pointer' }}>
                  <input type="checkbox" checked={form.isVegan} onChange={e => setForm({...form, isVegan: e.target.checked})} /> Vegan
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', cursor: 'pointer' }}>
                  <input type="checkbox" checked={form.isPopular} onChange={e => setForm({...form, isPopular: e.target.checked})} /> Popular ⭐
                </label>
              </div>
            </div>

            {/* Footer */}
            <div style={{ padding: '20px', background: '#fcfcfc', borderTop: '1px solid #eee', display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
              <button 
                onClick={() => setShowModal(false)}
                style={{ padding: '10px 20px', borderRadius: '6px', border: '1px solid #ddd', background: 'white', cursor: 'pointer' }}
              >
                Cancel
              </button>
              <button 
                onClick={handleSave}
                style={{ padding: '10px 20px', borderRadius: '6px', border: 'none', background: '#FF5C00', color: 'white', fontWeight: 'bold', cursor: 'pointer' }}
              >
                {editingItem ? 'Update Item' : 'Create Item'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MenuManagement;