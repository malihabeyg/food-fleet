import React, { useState, useEffect, useCallback } from 'react';
import { adminAPI } from '../../services/api';
import { FiSearch, FiToggleLeft, FiToggleRight, FiMail, FiPhone } from 'react-icons/fi';

const AdminUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [page, setPage] = useState(1);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const params = {
        page,
        limit: 20,
        search: search || undefined,
        role: roleFilter || undefined,
      };

      const response = await adminAPI.getUsers(params);

      const result = response.data?.data || response.data;
      setUsers(result.users || []);
    } catch (err) {
      console.error("Database fetch failed. Ensure backend routes exist.", err);
    } finally {
      setLoading(false);
    }
  }, [page, search, roleFilter]);

  useEffect(() => {
    const handler = setTimeout(() => {
      fetchUsers();
    }, 500);

    return () => clearTimeout(handler);
  }, [fetchUsers]);

  const toggleUserStatus = async (userId, currentStatus) => {
    try {
      await adminAPI.updateUserStatus(userId, !currentStatus);

      setUsers((prev) =>
        prev.map((u) =>
          u.id === userId ? { ...u, is_active: !currentStatus } : u
        )
      );
    } catch (err) {
      alert("Failed to update user status in database.");
    }
  };

  const roleIcons = {
    customer: '🛒',
    restaurant: '🍽️',
    rider: '🚴',
    admin: '🛡️',
  };

  return (
    <div className="main-content">
      <style>{customStyles}</style>

      <div className="page-header">
        <h1>👥 User Management</h1>
        <p className="subtitle">Manage platform permissions and account status</p>
      </div>

      {/* Filters */}
      <div className="filter-section">
        <div className="search-wrapper">
          <FiSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search by name or email..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
        </div>

        <select
          className="role-select"
          value={roleFilter}
          onChange={(e) => {
            setRoleFilter(e.target.value);
            setPage(1);
          }}
        >
          <option value="">All Roles</option>
          <option value="customer">🛒 Customers</option>
          <option value="restaurant">🍽️ Restaurants</option>
          <option value="rider">🚴 Riders</option>
          <option value="admin">🛡️ Admins</option>
        </select>
      </div>

      {/* Table */}
      <div className="table-card">
        {loading ? (
          <div className="table-loader">
            <div className="spinner"></div>
            <p>Fetching records...</p>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="user-table">
              <thead>
                <tr>
                  <th>User Details</th>
                  <th>Role</th>
                  <th>Contact</th>
                  <th>Status</th>
                  <th>Joined</th>
                  <th>Actions</th>
                </tr>
              </thead>

              <tbody>
                {users.length > 0 ? (
                  users.map((user) => (
                    <tr key={user.id}>
                      <td>
                        <div className="user-info-cell">
                          <div className={`avatar-box ${user.role}`}>
                            {user.first_name?.[0]}{user.last_name?.[0]}
                          </div>
                          <div>
                            <span className="user-name">
                              {user.first_name} {user.last_name}
                            </span>
                            <span className="user-id">
                              ID: {user.id ? String(user.id).slice(-6).toUpperCase() : 'N/A'}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td>
                        <span className={`role-tag ${user.role}`}>
                          {roleIcons[user.role]} {user.role}
                        </span>
                      </td>

                      <td>
                        <div className="contact-cell">
                          <small><FiMail /> {user.email}</small>
                          <small><FiPhone /> {user.phone || 'N/A'}</small>
                        </div>
                      </td>

                      <td>
                        <span className={`status-pill ${user.is_active ? 'active' : 'inactive'}`}>
                          {user.is_active ? 'Active' : 'Banned'}
                        </span>
                      </td>

                      <td>
                        {new Date(user.createdAt || user.created_at).toLocaleDateString()}
                      </td>

                      <td>
                        <button
                          className="action-toggle-btn"
                          onClick={() => toggleUserStatus(user.id, user.is_active)}
                        >
                          {user.is_active ? (
                            <FiToggleRight className="toggle-icon on" />
                          ) : (
                            <FiToggleLeft className="toggle-icon off" />
                          )}
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="empty-row">
                      No users found matching your filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

const customStyles = `
  .main-content { padding: 2rem; background: #f9fafb; min-height: 100vh; }
  .page-header h1 { font-size: 1.875rem; font-weight: 800; color: #111827; }
  .subtitle { color: #6b7280; margin-bottom: 2rem; }

  .filter-section { display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap; }

  .search-wrapper { position: relative; flex: 1; min-width: 300px; }
  .search-wrapper input {
    width: 100%;
    padding: 0.75rem 1rem 0.75rem 2.5rem;
    border: 1px solid #e5e7eb;
    border-radius: 0.75rem;
  }

  .role-select {
    padding: 0.75rem 1rem;
    border-radius: 0.75rem;
    border: 1px solid #e5e7eb;
  }

  .table-card { background: white; border-radius: 1rem; overflow: hidden; }

  .user-table { width: 100%; border-collapse: collapse; }
  .user-table th, .user-table td {
    padding: 1rem;
    border-bottom: 1px solid #f3f4f6;
  }

  .avatar-box {
    width: 40px; height: 40px;
    display: flex; align-items: center; justify-content: center;
    border-radius: 8px;
    font-weight: bold;
  }

  .status-pill.active { background: #dcfce7; color: #15803d; }
  .status-pill.inactive { background: #fee2e2; color: #b91c1c; }

  .spinner {
    width: 30px; height: 30px;
    border: 3px solid #eee;
    border-top: 3px solid #ff6b35;
    border-radius: 50%;
    animation: spin 1s linear infinite;
  }

  @keyframes spin { 100% { transform: rotate(360deg); } }
`;

export default AdminUsers;