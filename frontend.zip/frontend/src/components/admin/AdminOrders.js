import React, { useState, useEffect, useCallback } from 'react';
import { adminAPI } from '../../services/api';
import { FiTruck, FiRefreshCw, FiCheck, FiX } from 'react-icons/fi';

const AdminOrders = () => {
  const [orders, setOrders] = useState([]);
  const [riders, setRiders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [assigningOrderId, setAssigningOrderId] = useState(null);
  const [selectedRider, setSelectedRider] = useState('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (statusFilter) params.status = statusFilter;

      const [ordersRes, ridersRes] = await Promise.all([
        adminAPI.getOrders(params),
        adminAPI.getAvailableRiders(),
      ]);

      setOrders(ordersRes.data.orders || []);
      setRiders(ridersRes.data.riders || []);
    } catch (err) {
      console.error("Fetch failed, check backend logs", err);
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const assignRider = async (orderId, riderId) => {
    try {
      await adminAPI.assignRider(orderId, riderId);

      fetchData();
      setAssigningOrderId(null);
      setSelectedRider('');
    } catch (err) {
      alert("Failed to assign rider. Please try again.");
    }
  };

  const statusConfig = {
    pending: { label: 'Pending', badge: 'badge-pending', icon: '⏳' },
    confirmed: { label: 'Confirmed', badge: 'badge-confirmed', icon: '✅' },
    preparing: { label: 'Preparing', badge: 'badge-preparing', icon: '👨‍🍳' },
    ready: { label: 'Ready', badge: 'badge-ready', icon: '📦' },
    out_for_delivery: { label: 'Out for Delivery', badge: 'badge-out_for_delivery', icon: '🚴' },
    delivered: { label: 'Delivered', badge: 'badge-delivered', icon: '✅' },
    cancelled: { label: 'Cancelled', badge: 'badge-cancelled', icon: '❌' },
  };

  const filters = [
    { label: 'All', value: '' },
    { label: '⏳ Pending', value: 'pending' },
    { label: '👨‍🍳 Preparing', value: 'preparing' },
    { label: '📦 Ready', value: 'ready' },
    { label: '🚴 On Delivery', value: 'out_for_delivery' },
    { label: '✅ Delivered', value: 'delivered' },
  ];

  return (
    <div className="main-content">
      <div className="page-header">
        <h1>📦 Order Management</h1>
        <button className="btn btn-secondary btn-sm" onClick={fetchData}>
          <FiRefreshCw className={loading ? 'spin' : ''} /> Refresh Data
        </button>
      </div>

      {/* Filters */}
      <div className="filter-tabs" style={{ display: 'flex', gap: 10, marginBottom: 25, flexWrap: 'wrap' }}>
        {filters.map((f) => (
          <button
            key={f.value}
            className={`btn btn-sm ${statusFilter === f.value ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setStatusFilter(f.value)}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="loading-state">
          <div className="spinner"></div>
          <p>Connecting to database...</p>
        </div>
      ) : (
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer Details</th>
                <th>Restaurant</th>
                <th>Status</th>
                <th>Amount</th>
                <th>Rider Assignment</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {orders.length > 0 ? (
                orders.map((order) => {
                  const config = statusConfig[order.status] || {};
                  const needsRider =
                    ['confirmed', 'preparing', 'ready'].includes(order.status) &&
                    !order.rider_name;

                  const isAssigning = assigningOrderId === order.id;

                  return (
                    <tr key={order.id} className={needsRider ? 'row-alert' : ''}>
                      <td className="text-id">
                        #{order.id ? String(order.id).slice(-6).toUpperCase() : 'N/A'}
                      </td>

                      <td>
                        <div className="text-bold">{order.customer_name}</div>
                        <div className="text-muted">{order.delivery_address}</div>
                      </td>

                      <td>{order.restaurant_name}</td>

                      <td>
                        <span className={`badge ${config.badge}`}>
                          {config.icon} {config.label}
                        </span>
                      </td>

                      <td className="text-bold">
                        ${order.total_amount ? parseFloat(order.total_amount).toFixed(2) : '0.00'}
                      </td>

                      <td>
                        {order.rider_name ? (
                          <div className="rider-info">
                            <div className="text-bold">🚴 {order.rider_name}</div>
                            <div className="text-muted">{order.rider_phone}</div>
                          </div>
                        ) : (
                          <span className="text-unassigned">Waiting for Rider</span>
                        )}
                      </td>

                      <td className="text-muted">
                        {order.created_at
                          ? new Date(order.created_at).toLocaleDateString()
                          : 'N/A'}
                      </td>

                      <td>
                        {needsRider &&
                          (isAssigning ? (
                            <div className="assignment-actions">
                              <select
                                className="form-select-sm"
                                value={selectedRider}
                                onChange={(e) => setSelectedRider(e.target.value)}
                              >
                                <option value="">Select Rider</option>
                                {riders.map((r) => (
                                  <option key={r.id} value={r.id}>
                                    {r.first_name} ({r.vehicle_type})
                                  </option>
                                ))}
                              </select>

                              <button
                                className="btn-circle btn-success"
                                onClick={() => assignRider(order.id, selectedRider)}
                                disabled={!selectedRider}
                              >
                                <FiCheck />
                              </button>

                              <button
                                className="btn-circle btn-danger"
                                onClick={() => setAssigningOrderId(null)}
                              >
                                <FiX />
                              </button>
                            </div>
                          ) : (
                            <button
                              className="btn btn-primary btn-sm"
                              onClick={() => setAssigningOrderId(order.id)}
                            >
                              <FiTruck /> Assign Rider
                            </button>
                          ))}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan="8" className="empty-table">
                    No orders found in this category.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminOrders;