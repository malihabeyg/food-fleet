import React, { useState, useEffect, useCallback } from 'react';
import { adminAPI } from '../../services/api';
import {
  FiUsers, FiShoppingBag, FiDollarSign, FiPackage,
  FiTrendingUp, FiRefreshCw
} from 'react-icons/fi';

const AdminDashboard = () => {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchAnalytics = useCallback(async () => {
    setLoading(true);
    try {
      const response = await adminAPI.getAnalytics();
      
      // If your backend follows { success: true, data: { ... } }
      // we check for response.data.data, otherwise just response.data
      const result = response.data?.data || response.data;
      setAnalytics(result);
      
    } catch (err) {
      console.error("Fetch failed, check backend and routes:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAnalytics();
  }, [fetchAnalytics]);

  // Loading State
  if (loading) {
    return (
      <div className="dashboard-page-container">
        <style>{dashboardStyles}</style>
        <div className="loader-box">
          <div className="spinner"></div>
          <p>Syncing with Database...</p>
        </div>
      </div>
    );
  }

  // Destructure with default values to prevent "undefined" crashes
  const { 
    overview = {}, 
    today = {}, 
    orderVolume = [], 
    ordersByStatus = [] 
  } = analytics || {};

  return (
    <div className="dashboard-page-container">
      <style>{dashboardStyles}</style>
      
      <div className="dashboard-content">
        <header className="dashboard-header">
          <div className="header-text">
            <h1>Analytics Overview</h1>
            <p>Real-time data directly from the system database.</p>
          </div>
          <button className="refresh-btn" onClick={fetchAnalytics}>
            <FiRefreshCw />
            Update Data
          </button>
        </header>

        {/* Stats Grid */}
        <section className="stats-grid">
          <StatCard 
            icon={<FiShoppingBag />} color="orange" 
            label="Total Orders" value={overview.total_orders || 0} 
            trend="All time" 
          />
          <StatCard 
            icon={<FiDollarSign />} color="green" 
            label="Revenue" value={`$${(overview.total_revenue || 0).toLocaleString()}`} 
            trend="Delivered only" 
          />
          <StatCard 
            icon={<FiUsers />} color="blue" 
            label="Customers" value={overview.total_customers || 0} 
            trend="Total Registered" 
          />
          <StatCard 
            icon={<FiPackage />} color="purple" 
            label="Restaurants" value={overview.total_restaurants || 0} 
            trend="Active partners" 
          />
        </section>

        <div className="main-charts-row">
          {/* Weekly Volume Chart */}
          <div className="card chart-card">
            <div className="card-header">
              <h3>Weekly Order Volume</h3>
              <FiTrendingUp />
            </div>
            <div className="bar-chart">
              {orderVolume.length > 0 ? (
                orderVolume.map((day, idx) => {
                  const max = Math.max(...orderVolume.map(d => d.count), 1);
                  return (
                    <div key={idx} className="bar-column">
                      <div className="bar-pill" style={{ height: `${(day.count / max) * 100}%` }}></div>
                      <span className="bar-label">
                        {new Date(day.date).toLocaleDateString('en', { weekday: 'short' })}
                      </span>
                    </div>
                  );
                })
              ) : (
                <div className="empty-state">No data for last 7 days</div>
              )}
            </div>
          </div>

          {/* Orders by Status */}
          <div className="card status-card">
            <div className="card-header">
              <h3>Orders by Status</h3>
            </div>
            <div className="status-list">
              {ordersByStatus.length > 0 ? (
                ordersByStatus.map((item) => {
                  const total = ordersByStatus.reduce((sum, i) => sum + parseInt(i.count), 0);
                  const percent = ((parseInt(item.count) / total) * 100).toFixed(1);
                  return (
                    <div key={item.status} className="status-row">
                      <div className="status-info">
                        <span>{item.status.replace('_', ' ')}</span>
                        <strong>{percent}%</strong>
                      </div>
                      <div className="progress-track">
                        <div className="progress-fill" style={{ width: `${percent}%`, background: getStatusColor(item.status) }}></div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <p className="empty-state">No status records found</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helpers
const StatCard = ({ icon, color, label, value, trend }) => (
  <div className="stat-card">
    <div className={`icon-box ${color}`}>{icon}</div>
    <div>
      <p className="label">{label}</p>
      <h2 className="value">{value}</h2>
      <span className="trend">{trend}</span>
    </div>
  </div>
);

const getStatusColor = (s) => {
  const colors = { delivered: '#10B981', preparing: '#F59E0B', out_for_delivery: '#3B82F6', pending: '#EF4444' };
  return colors[s] || '#6B7280';
};

const dashboardStyles = `
  .dashboard-page-container {
    padding-left: 260px;
    background: #f8fafc;
    min-height: 100vh;
    width: 100%;
  }

  .dashboard-content {
    padding: 40px;
    max-width: 1400px;
    margin: 0 auto;
  }

  .dashboard-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 32px;
  }

  .header-text h1 { font-size: 28px; font-weight: 800; color: #1e293b; margin: 0; }
  .header-text p { color: #64748b; margin-top: 4px; }

  .refresh-btn {
    display: flex;
    align-items: center; gap: 8px;
    background: white; border: 1px solid #e2e8f0;
    padding: 10px 18px; border-radius: 10px;
    font-weight: 600; cursor: pointer;
  }

  .stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 24px; margin-bottom: 32px;
  }

  .stat-card {
    background: white; padding: 24px; border-radius: 16px;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
    display: flex; gap: 16px; align-items: center;
  }

  .icon-box {
    width: 54px; height: 54px; border-radius: 12px;
    display: grid; place-items: center; font-size: 22px; color: white;
  }
  .orange { background: #f97316; }
  .green { background: #10b981; }
  .blue { background: #3b82f6; }
  .purple { background: #8b5cf6; }

  .stat-card .label { color: #64748b; font-size: 14px; margin: 0; }
  .stat-card .value { font-size: 24px; font-weight: 700; color: #1e293b; margin: 4px 0; }
  .stat-card .trend { font-size: 12px; color: #64748b; font-weight: 500; }

  .main-charts-row {
    display: grid;
    grid-template-columns: 1.5fr 1fr;
    gap: 24px;
  }

  .card {
    background: white; padding: 24px; border-radius: 20px;
    box-shadow: 0 10px 15px -3px rgba(0,0,0,0.04);
  }

  .bar-chart { height: 250px; display: flex; align-items: flex-end; gap: 15px; }
  .bar-column { flex: 1; display: flex; flex-direction: column; align-items: center; height: 100%; justify-content: flex-end; }
  .bar-pill { width: 100%; background: #fb923c; border-radius: 6px 6px 0 0; }
  .bar-label { font-size: 12px; color: #64748b; margin-top: 10px; }

  .status-list { display: flex; flex-direction: column; gap: 20px; }
  .status-info { display: flex; justify-content: space-between; margin-bottom: 8px; text-transform: capitalize; font-size: 14px; }
  .progress-track { height: 8px; background: #f1f5f9; border-radius: 10px; overflow: hidden; }
  .progress-fill { height: 100%; border-radius: 10px; }

  .loader-box { min-height: 50vh; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 16px; }
  .spinner { width: 40px; height: 40px; border: 4px solid #f1f5f9; border-top: 4px solid #fb923c; border-radius: 50%; animation: spin 1s linear infinite; }
  @keyframes spin { 100% { transform: rotate(360deg); } }
  .empty-state { color: #94a3b8; font-style: italic; }

  @media (max-width: 1100px) {
    .main-charts-row { grid-template-columns: 1fr; }
  }
`;

export default AdminDashboard;