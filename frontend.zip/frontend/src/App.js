import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Sidebar from './components/shared/Sidebar';
import NotificationToast from './components/shared/NotificationToast';
import LoginPage from './components/shared/LoginPage';
import RegisterPage from './components/shared/RegisterPage';

// Customer
import CustomerDashboard from './components/customer/CustomerDashboard';
import RestaurantDetail from './components/customer/RestaurantDetail';
import CustomerOrders from './components/customer/CustomerOrders';

// Restaurant
import RestaurantDashboard from './components/restaurant/RestaurantDashboard';
import MenuManagement from './components/restaurant/MenuManagement';
import RestaurantOrders from './components/restaurant/RestaurantOrders';

// Rider
import RiderDashboard from './components/rider/RiderDashboard';
import RiderHistory from './components/rider/RiderHistory';

// Admin
import AdminDashboard from './components/admin/AdminDashboard';
import AdminUsers from './components/admin/AdminUsers';
import AdminOrders from './components/admin/AdminOrders';

import './styles/global.css';

// Protected Route Component
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <div className="spinner"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user?.role)) {
    return <Navigate to={`/${user?.role || 'login'}`} replace />;
  }

  return children;
};

// Layout with Sidebar
const DashboardLayout = ({ children }) => {
  return (
    <div className="app-container">
      <Sidebar />
      {children}
      <NotificationToast />
    </div>
  );
};

// Auth Layout (no sidebar)
const AuthLayout = ({ children }) => {
  return (
    <div>
      {children}
      <NotificationToast />
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route
            path="/login"
            element={
              <AuthLayout>
                <LoginPage />
              </AuthLayout>
            }
          />
          <Route
            path="/register"
            element={
              <AuthLayout>
                <RegisterPage />
              </AuthLayout>
            }
          />

          {/* Customer Routes */}
          <Route
            path="/customer"
            element={
              <ProtectedRoute allowedRoles={['customer']}>
                <DashboardLayout>
                  <CustomerDashboard />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/restaurants"
            element={
              <ProtectedRoute allowedRoles={['customer']}>
                <DashboardLayout>
                  <CustomerDashboard />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/restaurants/:id"
            element={
              <ProtectedRoute allowedRoles={['customer']}>
                <DashboardLayout>
                  <RestaurantDetail />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/orders"
            element={
              <ProtectedRoute allowedRoles={['customer']}>
                <DashboardLayout>
                  <CustomerOrders />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/orders/:id"
            element={
              <ProtectedRoute allowedRoles={['customer']}>
                <DashboardLayout>
                  <CustomerOrders />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/customer/favorites"
            element={
              <ProtectedRoute allowedRoles={['customer']}>
                <DashboardLayout>
                  <CustomerDashboard />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />

          {/* Restaurant Routes */}
          <Route
            path="/restaurant"
            element={
              <ProtectedRoute allowedRoles={['restaurant']}>
                <DashboardLayout>
                  <RestaurantDashboard />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/restaurant/menu"
            element={
              <ProtectedRoute allowedRoles={['restaurant']}>
                <DashboardLayout>
                  <MenuManagement />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/restaurant/orders"
            element={
              <ProtectedRoute allowedRoles={['restaurant']}>
                <DashboardLayout>
                  <RestaurantOrders />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/restaurant/reviews"
            element={
              <ProtectedRoute allowedRoles={['restaurant']}>
                <DashboardLayout>
                  <RestaurantDashboard />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/restaurant/settings"
            element={
              <ProtectedRoute allowedRoles={['restaurant']}>
                <DashboardLayout>
                  <RestaurantDashboard />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />

          {/* Rider Routes */}
          <Route
            path="/rider"
            element={
              <ProtectedRoute allowedRoles={['rider']}>
                <DashboardLayout>
                  <RiderDashboard />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/rider/deliveries"
            element={
              <ProtectedRoute allowedRoles={['rider']}>
                <DashboardLayout>
                  <RiderDashboard />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/rider/history"
            element={
              <ProtectedRoute allowedRoles={['rider']}>
                <DashboardLayout>
                  <RiderHistory />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/rider/earnings"
            element={
              <ProtectedRoute allowedRoles={['rider']}>
                <DashboardLayout>
                  <RiderDashboard />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />

          {/* Admin Routes */}
          <Route
            path="/admin"
            element={
              <ProtectedRoute allowedRoles={['admin']}>
                <DashboardLayout>
                  <AdminDashboard />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/users"
            element={
              <ProtectedRoute allowedRoles={['admin']}>
                <DashboardLayout>
                  <AdminUsers />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/orders"
            element={
              <ProtectedRoute allowedRoles={['admin']}>
                <DashboardLayout>
                  <AdminOrders />
                </DashboardLayout>
              </ProtectedRoute>
            }
          />
          

          {/* Default Redirect */}
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;