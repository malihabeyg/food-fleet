import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authAPI } from '../services/api';
import { connectSocket, disconnectSocket, onNotification, offNotification } from '../services/socket';

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState([]);

  // Load user on mount
  useEffect(() => {
    const token = localStorage.getItem('foodfleet_token');
    const savedUser = localStorage.getItem('foodfleet_user');
    
    if (token && savedUser) {
      try {
        const parsed = JSON.parse(savedUser);
        setUser(parsed);
        connectSocket(parsed.id);
      } catch {
        localStorage.removeItem('foodfleet_token');
        localStorage.removeItem('foodfleet_user');
      }
    }
    setLoading(false);
  }, []);

  // Socket notification listener
  useEffect(() => {
    if (user?.id) {
      const handleNotification = (notification) => {
        setNotifications((prev) => [notification, ...prev].slice(0, 50));
        // Show browser notification if permitted
        if (Notification.permission === 'granted') {
          new Notification('FoodFleet', {
            body: notification.message,
            icon: '/favicon.ico',
          });
        }
      };
      onNotification(handleNotification);
      return () => offNotification(handleNotification);
    }
  }, [user]);

  const login = useCallback(async (email, password) => {
    const response = await authAPI.login({ email, password });
    const { token, user: userData } = response.data;
    
    // Transform user data to include firstName/lastName
    const nameParts = (userData.name || '').split(' ');
    const transformedUser = {
      ...userData,
      firstName: nameParts[0] || '',
      lastName: nameParts.slice(1).join(' ') || '',
      id: userData.id,
    };
    
    localStorage.setItem('foodfleet_token', token);
    localStorage.setItem('foodfleet_user', JSON.stringify(transformedUser));
    setUser(transformedUser);
    connectSocket(transformedUser.id);
    return transformedUser;
  }, []);

  const register = useCallback(async (data) => {
    // Transform frontend data to match backend expectations
    const backendData = {
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      password: data.password,
      phone: data.phone || '',
      role: data.role,
      restaurantName: data.restaurantName,
      cuisineType: data.cuisineType,
      vehicleType: data.vehicleType,
    };
    
    const response = await authAPI.register(backendData);
    const { token, user: userData } = response.data;
    
    // Transform user data
    const nameParts = (userData.name || `${data.firstName} ${data.lastName}`).split(' ');
    const transformedUser = {
      ...userData,
      firstName: nameParts[0] || data.firstName,
      lastName: nameParts.slice(1).join(' ') || data.lastName,
      id: userData.id,
    };
    
    localStorage.setItem('foodfleet_token', token);
    localStorage.setItem('foodfleet_user', JSON.stringify(transformedUser));
    setUser(transformedUser);
    connectSocket(transformedUser.id);
    return transformedUser;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('foodfleet_token');
    localStorage.removeItem('foodfleet_user');
    setUser(null);
    setNotifications([]);
    disconnectSocket();
  }, []);

  const clearNotification = useCallback((index) => {
    setNotifications((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const clearAllNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  const value = {
    user,
    loading,
    login,
    register,
    logout,
    notifications,
    clearNotification,
    clearAllNotifications,
    isAuthenticated: !!user,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;