import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:5001/api';

const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('foodfleet_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('foodfleet_token');
      localStorage.removeItem('foodfleet_user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  getMe: () => api.get('/auth/me'),
};

// Customer API
export const customerAPI = {
  getRestaurants: (params) => api.get('/customer/restaurants', { params }),
  getRestaurant: (id) => api.get(`/customer/restaurants/${id}`),
  placeOrder: (data) => api.post('/customer/orders', data),
  getOrders: (params) => api.get('/customer/orders', { params }),
  getOrder: (id) => api.get(`/customer/orders/${id}`),
  reorder: (id) => api.post(`/customer/orders/${id}/reorder`),
  submitReview: (data) => api.post('/customer/reviews', data),
  getFavorites: () => api.get('/customer/favorites'),
  toggleFavorite: (restaurantId) => api.post('/customer/favorites', { restaurantId }),
};

// Restaurant API
export const restaurantAPI = {
  getProfile: () => api.get('/restaurant/profile'),
  updateProfile: (data) => api.put('/restaurant/profile', data),
  getCategories: () => api.get('/restaurant/categories'),
  createCategory: (data) => api.post('/restaurant/categories', data),
  updateCategory: (id, data) => api.put(`/restaurant/categories/${id}`, data),
  deleteCategory: (id) => api.delete(`/restaurant/categories/${id}`),
  getMenu: () => api.get('/restaurant/menu'),
  addMenuItem: (data) => api.post('/restaurant/menu', data),
  updateMenuItem: (id, data) => api.put(`/restaurant/menu/${id}`, data),
  deleteMenuItem: (id) => api.delete(`/restaurant/menu/${id}`),
  getOrders: (params) => api.get('/restaurant/orders', { params }),
  updateOrderStatus: (id, status) => api.put(`/restaurant/orders/${id}/status`, { status }),
  getStats: () => api.get('/restaurant/stats'),
};

// Rider API
export const riderAPI = {
  getProfile: () => api.get('/rider/profile'),
  updateAvailability: (data) => api.put('/rider/availability', data),
  getActiveOrders: () => api.get('/rider/orders/active'),
  getOrderHistory: (params) => api.get('/rider/orders/history', { params }),
  confirmPickup: (orderId) => api.put(`/rider/orders/${orderId}/pickup`),
  confirmDelivery: (orderId) => api.put(`/rider/orders/${orderId}/deliver`),
  getStats: () => api.get('/rider/stats'),
  
};

// Admin API
export const adminAPI = {
  getUsers: (params) => api.get('/admin/users', { params }),
  updateUserStatus: (id, isActive) => api.put(`/admin/users/${id}/status`, { isActive }),
  getOrders: (params) => api.get('/admin/orders', { params }),
  assignRider: (orderId, riderId) => api.put(`/admin/orders/${orderId}/assign-rider`, { riderId }),
  getAvailableRiders: () => api.get('/admin/riders/available'),
  getAnalytics: () => api.get('/admin/analytics'),
};

// Notifications API
export const notificationAPI = {
  getNotifications: (params) => api.get('/notifications', { params }),
  markAsRead: (id) => api.put(`/notifications/${id}/read`),
  markAllAsRead: () => api.put('/notifications/read-all'),
};

export default api;